# -*- coding: utf-8 -*-
# GNU General Public License v3.0 (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
"""Implements VRT MAX GraphQL API functionality"""

from datetime import datetime, timedelta
from urllib.parse import quote, quote_plus, unquote

from data import CHANNELS
from helperobjects import TitleItem
from kodiutils import (colour, delete_cached_thumbnail, get_cache, get_setting_bool, get_setting_int, get_url_json, has_addon, has_credentials,
                       localize, localize_datelong, localize_from_data, log, log_error, update_cache, url_for)
from utils import find_entry, reformat_image_url, shorten_link, url_to_program, youtube_to_plugin_url
from graphql_data import EPISODE_TILE, PROGRAM_TILE


SCREENSHOT_URL = 'https://www.vrt.be/vrtnu-static/screenshots'
GRAPHQL_URL = 'https://www.vrt.be/vrtnu-api/graphql/v1'
RESUMEPOINTS_URL = 'https://ddt.profiel.vrt.be/resumePoints'
RESUMEPOINTS_MARGIN = 30  # The margin at start/end to consider a video as watched
LIVESTREAM_CACHE_HOURS = 24


def get_sort(program_type):
    """Get sorting method"""
    sort = 'unsorted'
    ascending = True
    if program_type in ('mixed_episodes', 'daily'):
        sort = 'dateadded'
        ascending = False
    elif program_type == 'oneoff':
        sort = 'label'
    elif program_type in ('series', 'reeksoplopend'):
        sort = 'episode'
    elif program_type == 'reeksaflopend':
        sort = 'episode'
        ascending = False
    return sort, ascending


def get_context_menu(actions):
    """Get context menu for listitem"""
    context_menu = []

    for action in actions:
        action_type = action.get('action', {}).get('__typename')
        if action_type == 'FinishAction':
            context_menu.append((
                localize(30456),  # Mark as watched (VRT MAX)
                'RunPlugin(%s)' % url_for('resumepoints_continue_finish', episode_id=action.get('action', {}).get('id'))
            ))
        elif action_type == 'LinkAction':
            context_menu.append((
                localize(30417),  # Go to program
                'Container.Update(%s)' % url_for('programs', program_name=url_to_program(action.get('action', {}).get('link', '')))
            ))
        elif action_type == 'ListDeleteAction':
            list_name = action.get('action', {}).get('listName', None)
            # favorited = bool(action.get('action', {}).get('listName').split('|')[-1] in ('live/vrtmax/favorites%', 'vrtnu-favoritePrograms%'))
            from base64 import b64encode
            context_menu.append((
                localize(30455),  # Delete from this list (VRT MAX)
                'RunPlugin(%s)' % url_for('list_delete', episode_id=action.get('action', {}).get('id'),
                                          list_name=b64encode(list_name.encode('utf-8')).decode('utf-8'))
            ))
        elif action_type == 'FavoriteAction':
            from base64 import b64encode
            encoded_entity_id = b64encode(action.get('action', {}).get('id').encode('utf-8')).decode('utf-8')
            entity_type = action.get('action', {}).get('id').split('|')[2]
            follow_suffix = localize(30410)  # program
            if entity_type == 'video-episode':
                follow_suffix = localize(30409)  # episode

            encoded_favorite_title = quote_plus(action.get('action', {}).get('title', '') or '')  # We need to ensure forward slashes are quoted
            if action.get('action', {}).get('favorite'):
                context_menu.append((
                    localize(30412, title=follow_suffix),  # Unfollow
                    'RunPlugin(%s)' % url_for('unfollow', entity_id=encoded_entity_id, entity_title=encoded_favorite_title)
                ))
            else:
                context_menu.append((
                    localize(30411, title=follow_suffix),  # Follow
                    'RunPlugin(%s)' % url_for('follow', entity_id=encoded_entity_id, entity_title=encoded_favorite_title)
                ))
    return context_menu


def format_label(program_title, episode_title, program_type, start_dt=None, favorited=False, item_type='episode', is_playable=True, is_live=False):
    """Format label"""
    import dateutil.tz
    if item_type == 'program' or program_type == 'oneoff':
        label = program_title
    elif program_type == 'mixed_episodes':
        label = '[B]{}[/B] - {}'.format(program_title, episode_title)
    elif program_type == 'daily':
        label = '{} - {}'.format(start_dt.astimezone(dateutil.tz.gettz('Europe/Brussels')).strftime('%d/%m'), episode_title)
    elif program_type == 'epg':
        parts = [
            start_dt.astimezone(dateutil.tz.gettz('Europe/Brussels')).strftime("%H:%M"),
            '[B]{}[/B]'.format(program_title) if program_title else None,
            episode_title
        ]
        label = ' - '.join(p for p in parts if p)
    else:
        label = episode_title or ''

    # Favorite marker
    if favorited:
        label += '[COLOR={highlighted}]ᵛ[/COLOR]'

    # Non-actionable item
    if item_type == 'episode' and not is_playable:
        label = '[COLOR={{greyedout}}]{}[/COLOR]'.format(label)

    # Now playing
    if is_live:
        if item_type == 'episode' and is_playable:
            label = '[COLOR={{highlighted}}]{}[/COLOR] {}'.format(label, localize(30301))
        else:
            label += localize(30301)

    return colour(label)


def format_plot(plot, geoblocked, product_placement, mpaa, program_type=None, start_dt=None, stop_dt=None, offtime=None, permalink=None):
    """Format plot"""
    import dateutil.tz

    # Add additional metadata to plot
    plot_meta = ''
    plot_date = ''

    if program_type == 'epg' and start_dt and stop_dt:
        start_str = start_dt.astimezone(dateutil.tz.gettz('Europe/Brussels')).strftime("%H:%M")
        stop_str = stop_dt.astimezone(dateutil.tz.gettz('Europe/Brussels')).strftime("%H:%M")
        local_start = start_dt.astimezone(dateutil.tz.gettz('Europe/Brussels'))
        plot_date += f'[B]{localize_datelong(local_start)}[/B]\n{start_str} - {stop_str}'

    # Only display when a video disappears if it is within the next 3 months
    # Show the remaining days/hours the episode is still available
    if offtime:
        now = datetime.now(dateutil.tz.gettz('Europe/Brussels'))
        remaining = offtime - now
        total_seconds = remaining.total_seconds()

        if total_seconds <= 0:
            plot_meta += localize(30209)  # Already expired or 0 time left
        else:
            total_days = total_seconds / 86400
            if total_days > 5 * 365:
                pass  # more than 5 years, do not show
            elif total_days > 2 * 365:
                plot_meta += localize(30202, years=int(total_days // 365))
            elif total_days > 3 * 30.5:
                plot_meta += localize(30203, months=int(total_days // 30.5))
            elif total_days > 1:
                plot_meta += localize(30204, days=int(total_days))
            elif int(total_days) == 1:
                plot_meta += localize(30205)  # 1 day to go
            else:
                total_hours = total_seconds / 3600
                if total_hours > 1:
                    plot_meta += localize(30206, hours=int(total_hours))
                elif int(total_hours) == 1:
                    plot_meta += localize(30207)  # 1 hour to go
                else:
                    plot_meta += localize(30208, minutes=int(total_seconds // 60))

    if geoblocked:
        if plot_meta:
            plot_meta += '  '
        plot_meta += localize(30201)  # Geo-blocked

    # Add product placement
    if product_placement is True:
        if plot_meta:
            plot_meta += '  '
        plot_meta += '[B]PP[/B]'

    # Add film rating
    if mpaa:
        if plot_meta:
            plot_meta += '  '
        plot_meta += f'[B]{mpaa}[/B]'

    if plot_date:
        plot = f'{plot_date}\n\n{plot}'

    if plot_meta:
        plot = f'{plot}\n\n{plot_meta}'

    permalink = shorten_link(permalink)
    if permalink and get_setting_bool('showpermalink', default=False):
        plot = '{}\n\n[COLOR={{highlighted}}]{}[/COLOR]'.format(plot, permalink)
    return colour(plot)


def resumepoints_is_activated():
    """Is resumepoints activated in the menu and do we have credentials ?"""
    return get_setting_bool('usefavorites', default=True) and get_setting_bool('useresumepoints', default=True) and has_credentials()


def get_resumepoint_data(episode_id):
    """Get resumepoint data from GraphQL API"""
    if not episode_id:
        return None
    data_json = get_stream_data(episode_id)
    return next(
        (mode.get('resumePointTemplate', {})
         for mode in (data_json.get('data', {}).get('page') or {}).get('player', {}).get('modes', [])
         if mode.get('__typename') == 'VideoPlayerMode'),
        None
    )


def get_next_info(episode_id):
    """ Get up next data"""
    next_info = {}
    data_json = get_stream_data(episode_id)
    current_ep = data_json.get('data').get('page')
    current_ep_info = next((info for info in current_ep.get('components') if info.get('__typename') == 'MediaInfo'), None)
    # Only get add data when there is a next episode
    if current_ep.get('player').get('playlist').get('next'):
        edges = (
            current_ep
            .get('player', {})
            .get('playlist', {})
            .get('next', {})
            .get('paginatedItems', {})
            .get('edges', [])
        )
        next_ep = next((edge.get('node') for edge in edges), None)
        if next_ep:
            current_episode = {
                'episodeid': current_ep.get('id'),
                'tvshowid': current_ep.get('program', {}).get('id') or '1234',
                'title': current_ep.get('title'),
                'art': {
                    'tvshow.poster': None,
                    'thumb': current_ep.get('player').get('image').get('templateUrl'),
                    'tvshow.fanart': None,
                    'tvshow.landscape': current_ep.get('player').get('image').get('templateUrl'),
                    'tvshow.clearart': None,
                    'tvshow.clearlogo': None,
                },
                'plot': current_ep_info.get('description'),
                'showtitle': current_ep.get('player').get('subtitle'),
                'playcount': None,
                'season': next((lv.split()[1] for meta in (current_ep_info.get('secondaryMeta') or [])
                                if (lv := meta.get('longValue')) and 'Seizoen' in lv), 0),
                'episode': next((lv.split()[1] for meta in (current_ep_info.get('secondaryMeta') or [])
                                 if (lv := meta.get('longValue')) and 'Aflevering' in lv), 0),
                'rating': None,
                'firstaired': None,
                'runtime': int((current_ep.get('player', {}).get('progress') or {}).get('durationInSeconds', 0)),
            }
            next_episode = {
                'episodeid': next_ep.get('id'),
                'tvshowid': current_ep.get('program', {}).get('id'),
                'title': next_ep.get('title'),
                'art': {
                    'tvshow.poster': None,
                    'thumb': next_ep.get('image').get('templateUrl'),
                    'tvshow.fanart': None,
                    'tvshow.landscape': next_ep.get('image').get('templateUrl'),
                    'tvshow.clearart': None,
                    'tvshow.clearlogo': None,
                },
                'plot': next_ep.get('description'),
                'showtitle': current_ep.get('player').get('subtitle'),
                'playcount': None,
                'season': next((lv.split()[1] for meta in (next_ep.get('primaryMeta') or [])
                                if (lv := meta.get('longValue')) and 'Seizoen' in lv), 0),
                'episode': next((lv.split()[1] for meta in (next_ep.get('primaryMeta') or [])
                                 if (lv := meta.get('longValue')) and 'Aflevering' in lv), 0),
                'rating': None,
                'firstaired': None,
                'runtime': next_ep.get('status').get('durationSeconds', 0),
            }
            next_info = {
                'current_episode': current_episode,
                'next_episode': next_episode,
                'play_info': {
                    'episode_id': next_ep.get('action').get('link'),
                }
            }
    return next_info


def get_stream_data(page_id):
    """Get stream data from from GraphQL API"""
    graphql_query = """
         query StreamId($pageId: ID!) {
          page(id: $pageId) {
            ... on IPage {
              ... on LivestreamPage {
                player {
                  modes {
                    ... on VideoPlayerMode {
                      streamId
                    }
                    __typename
                  }
                }
              }
            }
            ... on EpisodePage {
              title
              brand
              player {
                title
                subtitle
                image {
                  templateUrl
                }
                progress {
                  durationInSeconds
                  progressInSeconds
                  completed
                }
                modes {
                  ... on VideoPlayerMode {
                    streamId
                    resumePointTemplate {
                      mediaId
                      mediaName
                    }
                  }
                  __typename
                }
                playlist {
                  autoPlay
                  next {
                    __typename
                    ... on PaginatedTileList {
                      paginatedItems(first: 1) {
                        edges {
                          node {
                            __typename
                            ... on EpisodeTile {
                              ...episodeTileFragment
                              __typename
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              components {
                ...mediaInfoFragment
              }
            }
          }
          __typename
        }
        fragment mediaInfoFragment on MediaInfo {
          __typename
          objectId
          title
          maxAge
          description
          accessibilityTitle
          actionItems {
            ...actionItemFragment
            __typename
          }
          image {
            ...imageFragment
            __typename
          }
          primaryMeta {
            ...metaFragment
            __typename
          }
          secondaryMeta {
            ...metaFragment
            __typename
          }
          tertiaryMeta {
            ...metaFragment
            __typename
          }
          quaternaryMeta {
            label
            ...metaFragment
            __typename
          }
        }
        fragment imageFragment on Image {
          __typename
          objectId
          alt
          focusPoint {
            x
            y
            __typename
          }
          templateUrl
        }
        fragment metaFragment on MetaDataItem {
          __typename
          type
          value
          shortValue
          longValue
        }
        fragment actionItemFragment on ActionItem {
          __typename
          objectId
          accessibilityLabel
          active
          mode
          title
          themeOverride
          action {
            ... on LinkAction {
              internalTarget
              link
              internalTarget
              externalTarget
              passUserIdentity
              zone {
                preferredZone
                isExclusive
                __typename
              }
              linkTokens {
                __typename
                placeholder
                value
              }
              __typename
            }
            __typename
          }
        }
        %s
    """ % EPISODE_TILE
    operation_name = 'StreamId'
    variables = {
        'pageId': page_id
    }
    return api_req(graphql_query, operation_name, variables)


def get_single_episode_data(episode_id):
    """Get single episode data from GraphQL API"""
    graphql_query = """
        query OnePlayerData($id: ID!) {
          page(id: $id) {
            __typename
            ... on EpisodePage {
              title
            }
          }
        }
    """
    operation_name = 'OnePlayerData'
    variables = {
        'id': episode_id,
    }
    return api_req(graphql_query, operation_name, variables)


def get_program_data(program_name):
    """Get program data from GraphQL API"""
    graphql_query = """
        query VideoProgramPage(
          $pageId: ID!,
          $lazyItemCount: Int = 500,
          $after: ID
          ) {
          page(id: $pageId) {
            ... on ProgramPage {
              header {
                title
                actionItems {
                  accessibilityLabel
                  active
                  mode
                  title
                  action {
                    ... on LinkAction {
                      __typename
                      internalTarget
                      link
                    }
                    ... on FavoriteAction {
                      __typename
                      title
                      id
                      favorite
                    }
                  }
                }
              }
              components {
                ... on ContainerNavigation {
                  items {
                    title
                    components {
                      __typename
                      ... on PaginatedTileList {
                        __typename
                        paginatedItems(first: $lazyItemCount, after: $after) {
                          __typename
                          edges {
                            __typename
                            cursor
                            node {
                              __typename
                              ... on EpisodeTile {
                                ...episodeTileFragment
                                __typename
                              }
                            }
                          }
                        }
                      }
                      ... on ContainerNavigation {
                        items {
                          title
                          components {
                            __typename
                            ... on PaginatedTileList {
                              __typename
                              paginatedItems(first: $lazyItemCount, after: $after) {
                                __typename
                                edges {
                                  __typename
                                  cursor
                                  node {
                                    __typename
                                    ... on EpisodeTile {
                                      ...episodeTileFragment
                                      __typename
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        fragment metaFragment on MetaDataItem {
          __typename
          type
          value
          shortValue
          longValue
          icons {
            ...iconFragment
            __typename
          }
        }
        fragment iconFragment on Icon {
          __typename
          accessibilityLabel
          position
          type
          ... on DesignSystemIcon {
            value {
              __typename
              color
              name
            }
            activeValue {
              __typename
              color
              name
            }
            __typename
          }
          ... on ImageIcon {
            value {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            activeValue {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            __typename
          }
        }
        %s
    """ % EPISODE_TILE
    operation_name = 'VideoProgramPage'
    variables = {
        'pageId': f'/vrtmax/a-z/{program_name}/',
    }
    return api_req(graphql_query, operation_name, variables)


def get_latest_episode_data(program_name):
    """Get latest episode data from GraphQL API"""
    import re
    latest_episode = None
    data = get_program_data(program_name)
    if data.get('data').get('page'):
        for action in data.get('data').get('page').get('header').get('actionItems'):
            if action.get('title') == 'Bekijk de recentste aflevering':
                latest_episode = get_stream_data(action.get('action').get('link')).get('data').get('page')
                break
            items = data.get('data').get('page').get('components')[0].get('items')[0].get('components')[0]
            if not items.get('paginatedItems'):
                items = items.get('items')[0].get('components')[0]
            edges = items.get('paginatedItems').get('edges')
            highest_ep_no = 0
            highest_ep = {}
            for edge in edges:
                ep_no = next(
                    (
                        int(m.group())
                        for meta in edge.get('node').get('primaryMeta') or []
                        if (m := re.search(
                            r'\b\d+\b',
                            meta.get('longValue') or meta.get('value') or ''
                        ))
                        and 'Aflevering' in (meta.get('longValue') or meta.get('value') or '')
                    ),
                    0
                )
                if ep_no > highest_ep_no:
                    highest_ep_no = ep_no
                    highest_ep = edge.get('node')
            latest_episode = highest_ep
    return latest_episode


def get_seasons_data(program_name):
    """Get seasons data from GraphQL API"""
    graphql_query = """
        query ProgramPage(
          $pageId: ID!
          $lazyItemCount: Int = 500
          $after: ID
          $before: ID
          $includeActionItems: Boolean = false
        ) {
          page(id: $pageId) {
            ... on ProgramPage {
              ...programPageFragment
              menu {
                ...tabMenuFragment
                __typename
              }
              components {
                __typename
                ... on IComponent {
                  ...componentTrackingDataFragment
                  __typename
                }
                ...containerNavigationComponentsFragment
                ... on ContainerNavigation {
                  __typename
                  objectId
                  accessibilityTitle
                  navigationType
                  items {
                    objectId
                    title
                    active
                    components {
                      ...containerNavigationComponentsFragment
                      ... on ContainerNavigation {
                        __typename
                        objectId
                        accessibilityTitle
                        navigationType
                        items {
                          objectId
                          title
                          components {
                            ...containerNavigationComponentsFragment
                            __typename
                          }
                          __typename
                        }
                      }
                      __typename
                    }
                    __typename
                  }
                }
              }
              __typename
            }
            ... on PodcastProgramPage {
              ...programPageFragment
              menu {
                ...tabMenuFragment
                __typename
              }
              __typename
            }
            ... on RadioProgramPage {
              ...programPageFragment
              menu {
                ...tabMenuFragment
                __typename
              }
              __typename
            }
            ...errorFragment
            __typename
          }
        }
        fragment programPageFragment on IPage {
          objectId
          permalink
          header {
            ...pageHeaderFragment
            __typename
          }
          popUp: nudge {
            ...popupFragment
            __typename
          }
          toast: nudge {
            ...toastFragment
            __typename
          }
          seo {
            ...seoFragment
            __typename
          }
          socialSharing {
            ...socialSharingFragment
            __typename
          }
          trackingData {
            ...trackingDataFragment
            __typename
          }
          ldjson
          ...errorFragment
          __typename
        }
        fragment tabMenuFragment on ContainerNavigation {
          __typename
          objectId
          accessibilityTitle
          navigationType
          items {
            __typename
            objectId
            title
            active
            components {
              ... on ContainerNavigation {
                __typename
                objectId
                accessibilityTitle
                navigationType
                items {
                  objectId
                  title
                  components {
                    ...containerNavigationComponentsFragment
                    __typename
                  }
                  __typename
                }
              }
              ...containerNavigationComponentsFragment
              __typename
            }
          }
        }
        fragment containerNavigationComponentsFragment on Component {
          ... on IComponent {
            __typename
            ...componentTrackingDataFragment
          }
          ... on Banner {
            ...bannerFragment
            __typename
          }
          ... on PaginatedTileList {
            ...paginatedTileListFragment
            __typename
          }
          ... on StaticTileList {
            ...staticTileListFragment
            __typename
          }
          ... on LazyTileList {
            objectId
            title
            listId
            __typename
          }
          ... on Text {
            ...textFragment
            __typename
          }
          ... on TagsList {
            objectId
            title
            tags {
              name
              title
              category
              __typename
            }
            __typename
          }
          ... on PresentersList {
            objectId
            title
            presenters {
              title
              type
              __typename
            }
            __typename
          }
          __typename
        }
        fragment bannerFragment on Banner {
          __typename
          objectId
          accessibilityTitle
          brand
          countdown {
            date
            __typename
          }
          richDescription {
            __typename
            text
          }
          image {
            objectId
            templateUrl
            alt
            focusPoint {
              x
              y
              __typename
            }
            __typename
          }
          title
          compactLayout
          textTheme
          backgroundColor
          style
          action {
            ...actionFragment
            __typename
          }
          actionItems {
            ...actionItemFragment
            __typename
          }
          titleArt {
            objectId
            templateUrl
            __typename
          }
          labelMeta {
            __typename
            type
            value
          }
          preview {
            video {
              objectId
              modes {
                __typename
                streamId
              }
              __typename
            }
            __typename
          }
          ... on IComponent {
            ...componentTrackingDataFragment
            __typename
          }
        }
        fragment actionFragment on Action {
          __typename
          ... on FavoriteAction {
            id
            favorite
            title
            __typename
          }
          ... on ListDeleteAction {
            listName
            id
            listId
            title
            __typename
          }
          ... on ListTileDeletedAction {
            listName
            id
            listId
            __typename
          }
          ... on LinkAction {
            internalTarget
            link
            internalTarget
            externalTarget
            page {
              __typename
              ... on ProfilePage {
                flow
                __typename
              }
            }
            passUserIdentity
            zone {
              preferredZone
              isExclusive
              __typename
            }
            linkTokens {
              __typename
              placeholder
              value
            }
            __typename
          }
          ... on ShareAction {
            title
            url
            __typename
          }
          ... on SwitchTabAction {
            referencedTabId
            link
            __typename
          }
          ... on FinishAction {
            id
            __typename
          }
        }
        fragment actionItemFragment on ActionItem {
          __typename
          objectId
          accessibilityLabel
          active
          mode
          title
          themeOverride
          action {
            ...actionFragment
            __typename
          }
          icons {
            ...iconFragment
            __typename
          }
        }
        fragment iconFragment on Icon {
          __typename
          accessibilityLabel
          position
          type
          ... on DesignSystemIcon {
            value {
              __typename
              color
              name
            }
            activeValue {
              __typename
              color
              name
            }
            __typename
          }
          ... on ImageIcon {
            value {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            activeValue {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            __typename
          }
        }
        fragment componentTrackingDataFragment on IComponent {
          trackingData {
            data
            perTrigger {
              trigger
              data
              template {
                id
                __typename
              }
              __typename
            }
            __typename
          }
          __typename
        }
        fragment paginatedTileListFragment on PaginatedTileList {
          __typename
          objectId
          listId
          action {
            ... on LinkAction {
              __typename
              externalTarget
              link
            }
            ... on SwitchTabAction {
              __typename
              link
              referencedTabId
            }
            __typename
          }
          banner {
            actionItems {
              ...actionItemFragment
              __typename
            }
            backgroundColor
            compactLayout
            description
            image {
              ...imageFragment
              __typename
            }
            titleArt {
              ...imageFragment
              __typename
            }
            textTheme
            title
            __typename
          }
          bannerSize
          displayType
          maxAge
          tileVariant
          paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
            __typename
            edges {
              __typename
              cursor
              node {
                __typename
                ...tileFragment
                ... on ComponentTile {
                  component {
                    ... on Spotlight {
                      __typename
                      objectId
                      title
                      introAction {
                        ...tileFragment
                        __typename
                      }
                      spotlight {
                        ...tileFragment
                        __typename
                      }
                      actionItems {
                        ...actionItemFragment
                        __typename
                      }
                      extra {
                        ... on PaginatedTileList {
                          ...basicPaginatedTileListFragment
                          __typename
                        }
                        ... on SpotlightNudge {
                          __typename
                          nudgeObjectId: objectId
                          nudgeTitle: title
                          nudgeDescription: description
                          button {
                            ...actionItemFragment
                            __typename
                          }
                          nudgeTrackingData: trackingData {
                            ...trackingDataFragment
                            __typename
                          }
                        }
                        __typename
                      }
                      brand
                      trackingData {
                        ...trackingDataFragment
                        __typename
                      }
                    }
                    __typename
                  }
                  __typename
                }
              }
            }
            pageInfo {
              __typename
              endCursor
              hasNextPage
              hasPreviousPage
              startCursor
            }
          }
          tileContentType
          title
          description
          ... on IComponent {
            ...componentTrackingDataFragment
            __typename
          }
        }
        fragment basicPaginatedTileListFragment on PaginatedTileList {
          __typename
          objectId
          listId
          bannerSize
          description
          displayType
          maxAge
          tileVariant
          tileContentType
          title
          paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
            __typename
            edges {
              __typename
              cursor
              node {
                __typename
                ...tileFragment
              }
            }
            pageInfo {
              __typename
              endCursor
              hasNextPage
              hasPreviousPage
              startCursor
            }
          }
          ... on IComponent {
            ...componentTrackingDataFragment
            __typename
          }
        }
        fragment tileFragment on Tile {
          ... on IIdentifiable {
            __typename
            objectId
          }
          ... on IComponent {
            ...componentTrackingDataFragment
            __typename
          }
          ... on ITile {
            title
            active
            accessibilityTitle
            componentId
            tileType
            action {
              __typename
              ... on LinkAction {
                internalTarget
                link
                internalTarget
                externalTarget
                __typename
              }
            }
            actionItems @include(if: $includeActionItems) {
              ...actionItemFragment
              __typename
            }
            image {
              ...imageFragment
              __typename
            }
            primaryMeta {
              ...metaFragment
              __typename
            }
            secondaryMeta {
              ...metaFragment
              __typename
            }
            indexMeta {
              __typename
              type
              value
            }
            status {
              accessibilityLabel
              icon {
                ...iconFragment
                __typename
              }
              text {
                small
                default
                __typename
              }
              __typename
            }
            labelMeta {
              __typename
              type
              value
            }
            __typename
          }
          ... on ContentTile {
            brand
            brandLogos {
              ...brandLogosFragment
              __typename
            }
            __typename
          }
          ... on BannerTile {
            backgroundColor
            brand
            brandLogos {
              ...brandLogosFragment
              __typename
            }
            compactLayout
            description
            actionItems {
              ...actionItemFragment
              __typename
            }
            preview {
              __typename
              video {
                objectId
                modes {
                  __typename
                  streamId
                }
                __typename
              }
            }
            textTheme
            titleArt {
              objectId
              templateUrl
              __typename
            }
            __typename
          }
          ... on EpisodeTile {
            description
            available
            chapterStart
            progress {
              completed
              progressInSeconds
              durationInSeconds
              __typename
            }
            __typename
          }
          ... on PodcastEpisodeTile {
            available
            description
            progress {
              completed
              progressInSeconds
              durationInSeconds
              __typename
            }
            __typename
          }
          ... on AudioLivestreamTile {
            brand
            brandsLogos {
              brand
              brandTitle
              logos {
                ...brandLogosFragment
                __typename
              }
              __typename
            }
            description
            actionItems {
              ...actionItemFragment
              __typename
            }
            progress {
              durationInSeconds
              progressInSeconds
              __typename
            }
            tertiaryMeta {
              ...metaFragment
              __typename
            }
            __typename
          }
          ... on LivestreamTile {
            description
            progress {
              durationInSeconds
              progressInSeconds
              __typename
            }
            __typename
          }
          ... on ButtonTile {
            mode
            icons {
              ...iconFragment
              __typename
            }
            __typename
          }
          ... on RadioEpisodeTile {
            available
            description
            progress {
              completed
              progressInSeconds
              durationInSeconds
              __typename
            }
            __typename
          }
          ... on RadioFragmentTile {
            progress {
              completed
              progressInSeconds
              durationInSeconds
              __typename
            }
            __typename
          }
          ... on SongTile {
            startDate
            formattedStartDate
            endDate
            description
            __typename
          }
          __typename
        }
        fragment brandLogosFragment on Logo {
          colorOnColor
          height
          mono
          primary
          type
          width
          __typename
        }
        fragment imageFragment on Image {
          __typename
          objectId
          alt
          focusPoint {
            x
            y
            __typename
          }
          templateUrl
        }
        fragment metaFragment on MetaDataItem {
          __typename
          type
          value
          shortValue
          longValue
          icons {
            ...iconFragment
            __typename
          }
        }
        fragment trackingDataFragment on PageTrackingData {
          data
          perTrigger {
            trigger
            data
            template {
              id
              __typename
            }
            __typename
          }
          __typename
        }
        fragment staticTileListFragment on StaticTileList {
          __typename
          objectId
          listId
          title
          description
          tileContentType
          displayType
          maxAge
          tileVariant
          action {
            ... on LinkAction {
              __typename
              externalTarget
              link
            }
            ... on SwitchTabAction {
              __typename
              link
              referencedTabId
            }
            __typename
          }
          banner {
            actionItems {
              ...actionItemFragment
              __typename
            }
            description
            image {
              ...imageFragment
              __typename
            }
            compactLayout
            backgroundColor
            textTheme
            title
            titleArt {
              objectId
              templateUrl
              __typename
            }
            __typename
          }
          bannerSize
          items {
            ...tileFragment
            __typename
          }
          ... on IComponent {
            ...componentTrackingDataFragment
            __typename
          }
        }
        fragment textFragment on Text {
          __typename
          objectId
          html
        }
        fragment pageHeaderFragment on PageHeader {
          objectId
          accessibilityTitle
          brandsLogos {
            brandTitle
            __typename
          }
          presenters {
            title
            __typename
          }
          title
          titleArt {
            objectId
            templateUrl
            __typename
          }
          richDescription {
            __typename
            html
          }
          actionItems {
            ...actionItemFragment
            __typename
          }
          primaryMeta {
            type
            value
            shortValue
            __typename
          }
          secondaryMeta {
            type
            value
            shortValue
            longValue
            __typename
          }
          tertiaryMeta {
            type
            value
            shortValue
            __typename
          }
          image {
            __typename
            objectId
            focusPoint {
              x
              y
              __typename
            }
            templateUrl
          }
          __typename
        }
        fragment seoFragment on SeoProperties {
          __typename
          title
          description
        }
        fragment socialSharingFragment on SocialSharingProperties {
          __typename
          title
          description
          image {
            __typename
            objectId
            templateUrl
          }
        }
        fragment popupFragment on PopUp {
          __typename
          brand
          brandsLogos {
            ...brandLogo
            __typename
          }
          buttons {
            ...actionItemFragment
            __typename
          }
          description
          image {
            ...imageFragment
            __typename
          }
          objectId
          size
          status {
            text {
              default
              small
              __typename
            }
            icon {
              ...iconFragment
              __typename
            }
            __typename
          }
          title
          videoStreamId
          trackingData {
            ...trackingDataFragment
            __typename
          }
        }
        fragment brandLogo on BrandLogo {
          brand
          brandTitle
          logos {
            type
            primary
            colorOnColor
            __typename
          }
          __typename
        }
        fragment toastFragment on Toast {
          __typename
          description
          image {
            ...imageFragment
            __typename
          }
          objectId
          title
        }
        fragment errorFragment on ErrorPage {
          errorComponents: components {
            ...noContentFragment
            __typename
          }
          __typename
        }
        fragment noContentFragment on NoContent {
          __typename
          objectId
          title
          text
          backgroundImage {
            ...imageFragment
            __typename
          }
          mainImage {
            ...imageFragment
            __typename
          }
          noContentType
          actionItems {
            ...actionItemFragment
            __typename
          }
        }
    """
    operation_name = 'ProgramPage'
    variables = {
        'pageId': '/vrtmax/a-z/{}/'.format(program_name),
    }
    return api_req(graphql_query, operation_name, variables)


def set_favorite(entity_id, favorited=True):
    """Set favorite(add/remove to/from my list)"""
    graphql_query = """
        mutation setFavorite($input: FavoriteActionInput!) {
          setFavorite(input: $input) {
            __typename
            actionItem {
              __typename
              objectId
              accessibilityLabel
              action {
                ... on FavoriteAction {
                  __typename
                  id
                  favorite
                }
                __typename
              }
              active
              title
            }
            nudge {
              ... on Toast {
                __typename
                objectId
                description
                image {
                  __typename
                  objectId
                  alt
                  templateUrl
                }
              }
              __typename
            }
          }
        }
    """
    operation_name = 'setFavorite'
    variables = {
        'input': {
            'favorite': favorited,
            'id': entity_id,
        },
    }
    return api_req(graphql_query, operation_name, variables)


def is_favorite(program_name):
    """Wether a program a favorited"""
    data = get_program_data(program_name)
    favorite = next(
        (action.get('action').get('favorite') for action in data.get('data').get('page').get('header').get('actionItems', []) or []
         if action.get('action').get('__typename') == 'FavoriteAction'),
        ''
    )
    return favorite


def get_program_id(program_name):
    """Get the id of a program"""
    data = get_program_data(program_name)
    program_id = next(
        (action.get('action').get('id') for action in data.get('data').get('page').get('header').get('actionItems', []) or []
         if action.get('action').get('__typename') == 'FavoriteAction'),
        ''
    )
    return program_id


def set_resumepoint(video_id, title, position, total):
    """Set resumepoint"""
    data_json = {}
    # Respect resumepoint margins
    if position and total:
        if position < RESUMEPOINTS_MARGIN:
            position = 0
        if position > total - RESUMEPOINTS_MARGIN:
            position = total

    from tokenresolver import TokenResolver
    access_token = TokenResolver().get_token('vrtnu-site_profile_at')
    if access_token:
        gdpr = '{} gekeken tot {} seconden.'.format(title, position)
        headers = {
            'Authorization': 'Bearer ' + access_token,
            'Content-Type': 'application/json',
        }
        payload = {
            'at': position,
            'total': total,
            'gdpr': gdpr,
        }
        from json import dumps
        data = dumps(payload).encode('utf-8')
        data_json = get_url_json(url='{}/{}'.format(RESUMEPOINTS_URL, video_id), cache=None, headers=headers, data=data, raise_errors='all')
        log(3, '[Resumepoints] Updated resumepoint {data}', data=data_json)
    return data_json


def delete_from_list(episode_id, list_name):
    """Delete episode from list using GraphQL API"""
    graphql_query = """
        mutation listDelete($input: ListDeleteActionInput!) {
          setListDeleteActionItem(input: $input) {
            title
            active
            action {
              __typename
              ... on NoAction {
                __typename
                reason
              }
              ... on ListTileDeletedAction {
                __typename
                listId
                listName
                id
              }
            }
            __typename
          }
        }
    """
    operation_name = 'listDelete'
    variables = {
        'input': {
            'id': episode_id,
            'listName': list_name,
        },
    }
    return api_req(graphql_query, operation_name, variables)


def finish_continue(episode_id):
    """Finish continue episode using GraphQL API"""
    graphql_query = """
        mutation finishItem($input: FinishActionInput!) {
          setFinishActionItem(input: $input) {
            __typename
            objectId
            title
            accessibilityLabel
            action {
              ... on FinishAction {
                id
                __typename
              }
              __typename
            }
          }
        }
    """
    operation_name = 'finishItem'
    variables = {
        'input': {
            'id': episode_id,
        },
    }
    return api_req(graphql_query, operation_name, variables)


def get_entities(list_id, page_size='', end_cursor=''):
    """Get a list of episodes or programs using GraphQL API"""
    graphql_query = """
         query TileList(
          $listId: ID!
          $lazyItemCount: Int = 20
          $after: ID
          $before: ID
        ) {
          list(listId: $listId) {
            __typename
            ... on PaginatedTileList {
              ...paginatedTileListFragment
              __typename
            }
            ... on StaticTileList {
              ...staticTileListFragment
              __typename
            }
          }
        }
        fragment paginatedTileListFragment on PaginatedTileList {
          __typename
          objectId
          listId
          tileVariant
          tileContentType
          title
          description
          paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
            __typename
            edges {
              __typename
              cursor
              node {
                __typename
                ...tileFragment
              }
            }
            pageInfo {
              __typename
              endCursor
              hasNextPage
              hasPreviousPage
              startCursor
            }
          }
        }
        fragment staticTileListFragment on StaticTileList {
          __typename
          objectId
          listId
          tileVariant
          tileContentType
          title
          description
          paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
            __typename
            edges {
              __typename
              cursor
              node {
                __typename
                ...tileFragment
              }
            }
            pageInfo {
              __typename
              endCursor
              hasNextPage
              hasPreviousPage
              startCursor
            }
          }
        }
        fragment tileFragment on Tile {
          ... on IIdentifiable {
            __typename
            objectId
          }
          ... on ITile {
            title
            active
            accessibilityTitle
            action {
              __typename
              ... on LinkAction {
                internalTarget
                link
                internalTarget
                externalTarget
                __typename
              }
            }
            actionItems {
              ...actionItemFragment
              __typename
            }
            image {
              ...imageFragment
              __typename
            }
            primaryMeta {
              ...metaFragment
              __typename
            }
            secondaryMeta {
              ...metaFragment
              __typename
            }
            tertiaryMeta {
              ...metaFragment
              __typename
            }
            indexMeta {
              ...metaFragment
              __typename
            }
            statusMeta {
              ...metaFragment
              __typename
            }
            labelMeta {
              ...metaFragment
              __typename
            }
            status {
              accessibilityLabel
              icon {
                __typename
              }
              text {
                small
                default
                __typename
              }
              __typename
            }
            componentId
            __typename
          }
          ... on EpisodeTile {
            ...episodeTileFragment
            __typename
          }
          ... on ProgramTile {
            ...programTileFragment
          }
          __typename
        }
        fragment actionItemFragment on ActionItem {
          __typename
          objectId
          accessibilityLabel
          active
          mode
          title
          themeOverride
          action {
            ...actionFragment
            __typename
          }
          icons {
            ...iconFragment
            __typename
          }
        }
        fragment actionFragment on Action {
          __typename
          ... on FavoriteAction {
            id
            favorite
            title
            __typename
          }
          ... on ListDeleteAction {
            listName
            id
            listId
            title
            __typename
          }
          ... on ListTileDeletedAction {
            listName
            id
            listId
            __typename
          }
          ... on LinkAction {
            internalTarget
            link
            internalTarget
            externalTarget
            passUserIdentity
            zone {
              preferredZone
              isExclusive
              __typename
            }
            linkTokens {
              __typename
              placeholder
              value
            }
            __typename
          }
          ... on ShareAction {
            title
            url
            __typename
          }
          ... on SwitchTabAction {
            referencedTabId
            link
            __typename
          }
          ... on FinishAction {
            id
            __typename
          }
        }
        fragment iconFragment on Icon {
          __typename
          accessibilityLabel
          position
          type
          ... on DesignSystemIcon {
            value {
              __typename
              color
              name
            }
            activeValue {
              __typename
              color
              name
            }
            __typename
          }
          ... on ImageIcon {
            value {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            activeValue {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            __typename
          }
        }
        fragment imageFragment on Image {
          __typename
          objectId
          alt
          focusPoint {
            x
            y
            __typename
          }
          templateUrl
        }
        fragment metaFragment on MetaDataItem {
          __typename
          type
          value
          shortValue
          longValue
          icons {
            ...iconFragment
            __typename
          }
        }
        %s
        %s
    """ % (PROGRAM_TILE, EPISODE_TILE)
    operation_name = 'TileList'
    variables = {
        'listId': list_id,
        'after': end_cursor,
        'lazyItemCount': page_size,
    }
    return api_req(graphql_query, operation_name, variables)


def get_epg_page(page_id, page_size='', end_cursor=''):
    """Get a program guide page using GraphQL API"""
    graphql_query = """
        query Page(
          $pageId: ID!
          $lazyItemCount: Int = 100
          $after: ID
          $before: ID
        ) {
          page(id: $pageId) {
            ... on IIdentifiable {
              __typename
              objectId
            }
            ... on ElectronicProgramGuidePage {
              brand
              brandLogos {
                ...brandLogosFragment
                __typename
              }
              current {
                __typename
                objectId
                title
                ... on StandaloneTile {
                  __typename
                  objectId
                  tile {
                    ...tileFragment
                    __typename
                  }
                }
              }
              linkTemplate
              previous {
                __typename
                ...paginatedTileListFragment
              }
              next {
                __typename
                ...paginatedTileListFragment
              }
              __typename
            }
            ... on IPage {
              title
              permalink
              __typename
            }
            __typename
          }
        }
        fragment tileFragment on Tile {
          ... on IIdentifiable {
            __typename
            objectId
          }
          ... on IComponent {
            ...componentTrackingDataFragment
            __typename
          }
          ... on ITile {
            title
            active
            accessibilityTitle
            tileType
            action {
              __typename
              ... on LinkAction {
                internalTarget
                link
                internalTarget
                externalTarget
                __typename
              }
            }
            actionItems {
              ...actionItemFragment
              __typename
            }
            image {
              ...imageFragment
              __typename
            }
            primaryMeta {
              ...metaFragment
              __typename
            }
            secondaryMeta {
              ...metaFragment
              __typename
            }
            indexMeta {
              __typename
              type
              value
            }
            statusMeta {
              ...metaFragment
              __typename
            }
            status {
              accessibilityLabel
              icon {
                ...iconFragment
                __typename
              }
              text {
                small
                default
                __typename
              }
              __typename
            }
            labelMeta {
              __typename
              type
              value
            }
            componentId
            __typename
          }
          ... on EpisodeTile {
            tileType
            title
            componentType
            description
            available
            chapterStart
            formattedDuration
            progress {
              completed
              progressInSeconds
              durationInSeconds
              __typename
            }
            whatsonId
            __typename
          }
          ... on LivestreamTile {
            description
            brand
            progress {
              durationInSeconds
              progressInSeconds
              __typename
            }
            componentId
            __typename
          }
          __typename
        }
        fragment actionItemFragment on ActionItem {
          __typename
          objectId
          accessibilityLabel
          active
          mode
          title
          themeOverride
          action {
            ...actionFragment
            __typename
          }
          icons {
            ...iconFragment
            __typename
          }
        }
        fragment actionFragment on Action {
          __typename
          ... on FavoriteAction {
            id
            favorite
            title
            __typename
          }
          ... on LinkAction {
            internalTarget
            link
            internalTarget
            externalTarget
            passUserIdentity
            zone {
              preferredZone
              isExclusive
              __typename
            }
            linkTokens {
              __typename
              placeholder
              value
            }
            __typename
          }
          ... on ShareAction {
            title
            url
            __typename
          }
          ... on FinishAction {
            id
            __typename
          }
        }
        fragment iconFragment on Icon {
          __typename
          accessibilityLabel
          position
          type
          ... on DesignSystemIcon {
            value {
              __typename
              color
              name
            }
            activeValue {
              __typename
              color
              name
            }
            __typename
          }
          ... on ImageIcon {
            value {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            activeValue {
              __typename
              srcSet {
                src
                format
                __typename
              }
            }
            __typename
          }
        }
        fragment brandLogosFragment on Logo {
          colorOnColor
          height
          mono
          primary
          type
          width
          __typename
        }
        fragment componentTrackingDataFragment on IComponent {
          trackingData {
            data
            perTrigger {
              trigger
              data
              template {
                id
                __typename
              }
              __typename
            }
            __typename
          }
          __typename
        }
        fragment imageFragment on Image {
          __typename
          objectId
          alt
          focusPoint {
            x
            y
            __typename
          }
          templateUrl
        }
        fragment metaFragment on MetaDataItem {
          __typename
          type
          value
          shortValue
          longValue
        }
        fragment paginatedTileListFragment on PaginatedTileList {
          __typename
          objectId
          listId
          action {
            ... on LinkAction {
              __typename
              externalTarget
              link
            }
            __typename
          }
          banner {
            actionItems {
              ...actionItemFragment
              __typename
            }
            backgroundColor
            compactLayout
            description
            image {
              ...imageFragment
              __typename
            }
            titleArt {
              ...imageFragment
              __typename
            }
            textTheme
            title
            __typename
          }
          bannerSize
          displayType
          maxAge
          tileVariant
          paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
            __typename
            edges {
              __typename
              cursor
              node {
                __typename
                ...tileFragment
              }
            }
            pageInfo {
              __typename
              endCursor
              hasNextPage
              hasPreviousPage
              startCursor
            }
          }
          tileContentType
          title
          description
          ... on IComponent {
            ...componentTrackingDataFragment
            __typename
          }
        }
    """
    operation_name = 'Page'
    variables = {
        'pageId': page_id,
        'after': end_cursor,
        'lazyItemCount': page_size,
    }
    return api_req(graphql_query, operation_name, variables)


def get_epg_list(channel, date, page=None):
    """Generate EPG list from the EPG page. If page is None, return full list."""

    page_size = get_setting_int('itemsperpage', default=50)
    api_page_size = 50

    # Base page
    channel = find_entry(CHANNELS, 'name', channel).get('live_stream').split('/')[-2]
    page_id = f'/vrtmax/tv-gids/{channel}/{date}/'
    base = get_epg_page(page_id, page_size=api_page_size, end_cursor='')

    api_page = base.get('data', {}).get('page', {}) or {}
    prev_page = api_page.get('previous', {}) or {}
    next_page = api_page.get('next', {}) or {}
    current = api_page.get('current') or {}
    current_item = current.get('tile')

    # Initial blocks available
    prev_items = prev_page.get('paginatedItems', {}).get('edges') or []
    next_items = next_page.get('paginatedItems', {}).get('edges') or []

    prev_info = prev_page.get('paginatedItems', {}).get('pageInfo', {}) or {}
    next_info = next_page.get('paginatedItems', {}).get('pageInfo', {}) or {}

    prev_list_id = prev_page.get('listId')
    next_list_id = next_page.get('listId')

    # Count known items
    def known_total():
        return len(prev_items) + (1 if current_item else 0) + len(next_items)

    # Load a 50-item API block
    def load_more(list_id, page_info, collector):
        has_more = page_info.get('hasNextPage', False)
        cursor = page_info.get('endCursor')
        if not list_id or not has_more:
            return False, page_info

        data = get_entities(list_id=list_id, page_size=api_page_size, end_cursor=cursor)
        p = data.get('data', {}).get('list', {}).get('paginatedItems', {}) or {}
        edges = p.get('edges') or []
        collector.extend(edges)
        info = p.get('pageInfo', {}) or {}
        return info.get('hasNextPage', False), info

    prev_has_more = prev_info.get('hasNextPage', False)
    next_has_more = next_info.get('hasNextPage', False)

    # full list mode
    if page is None:
        # load everything until both sides exhausted
        while prev_has_more or next_has_more:
            if prev_has_more:
                prev_has_more, prev_info = load_more(prev_list_id, prev_info, prev_items)
            if next_has_more:
                next_has_more, next_info = load_more(next_list_id, next_info, next_items)

        # merge everything
        full = prev_items + ([current_item] if current_item else []) + next_items
        return full, ''  # no next page

    # paged mode
    page = int(page)
    offset = (page - 1) * page_size
    end_index = offset + page_size

    # fetch only what we need
    while known_total() < end_index and (prev_has_more or next_has_more):
        index_of_current = len(prev_items)
        current_count = 1 if current_item else 0

        if offset >= index_of_current + current_count:
            # page lies after the current item
            if next_has_more:
                next_has_more, next_info = load_more(next_list_id, next_info, next_items)
            elif prev_has_more:
                prev_has_more, prev_info = load_more(prev_list_id, prev_info, prev_items)
            else:
                break
        else:
            # page lies before the current item
            if prev_has_more:
                prev_has_more, prev_info = load_more(prev_list_id, prev_info, prev_items)
            elif next_has_more:
                next_has_more, next_info = load_more(next_list_id, next_info, next_items)
            else:
                break

    # merge
    full = prev_items + ([current_item] if current_item else []) + next_items

    # slice
    page_slice = full[offset:end_index]

    # determine next page
    if len(full) > end_index:
        next_page = str(page + 1)
    else:
        next_page = str(page + 1) if (next_has_more or prev_has_more) and page_slice else ''

    return page_slice, next_page


def get_epg_episodes(channel, date, page):
    """Return Title items from epg data"""
    tile_list, next_page = get_epg_list(channel, date, page=page)
    episodes, _, _ = convert_episodes(tile_list, destination='tvguide', end_cursor=next_page, date=date, channel=channel)
    return episodes


def convert_programs(item_list, destination, end_cursor='', use_favorites=False, **kwargs):
    """Convert paginated list of programs to Kodi list items"""

    programs = []

    for item in item_list:
        program = item.get('node')
        preview = program.get('preview', {})
        heading = preview.get('heading', {})

        program_name = url_to_program(program.get('link'))
        program_type = program.get('programType')
        program_title = program.get('title')
        episode_title = None
        ontime = None
        path = url_for('programs', program_name=program_name)
        plot = program.get('description')
        plotoutline = None

        # Art
        thumb = ''
        poster = ''
        banner = ''
        fanart = ''
        poster_img = program.get('image')
        if poster_img:
            poster = reformat_image_url(poster_img.get('templateUrl'))
        banner_img = heading.get('titleArt')
        if banner_img:
            banner = reformat_image_url(banner_img.get('templateUrl'))
        fanart_img = heading.get('image')
        if fanart_img:
            fanart = reformat_image_url(fanart_img.get('templateUrl'))

        # Check favorite
        favorite_action = next(
            (item.get('action') for item in program.get('actionItems', []) if item.get('action', {}).get('__typename', {}) == 'FavoriteAction'), {})
        if favorite_action:
            favorited = favorite_action.get('favorite')
        else:
            listdelete_action = next(
                (item.get('action') for item in program.get('actionItems', []) if item.get('action', {}).get('__typename', {}) == 'ListDeleteAction'), {})
            favorited = bool(listdelete_action.get('listName', '').split('|')[-1] == 'vrtnu-favoritePrograms%')

        # Filter favorites for favorites menu
        if use_favorites and favorited is False:
            continue

        # Context menu
        context_menu = get_context_menu(program.get('actionItems', []))

        # Label
        label = format_label(program_title, episode_title, program_type, ontime, favorited, item_type='program')

        programs.append(
            TitleItem(
                label=label,
                path=path,
                art_dict={
                    'thumb': thumb,
                    'poster': poster,
                    'banner': banner,
                    'fanart': fanart,
                },
                info_dict={
                    'title': label,
                    'tvshowtitle': program_title,
                    'plot': plot,
                    'plotoutline': plotoutline,
                    'mediatype': 'tvshow',
                },
                context_menu=context_menu,
                is_playable=False,
            )
        )

    # Paging
    # Remove kwargs with None value
    kwargs = {k: v for k, v in list(kwargs.items()) if v is not None}

    if end_cursor:
        # Add 'More...' entry at the end
        programs.append(
            TitleItem(
                label=colour(localize(30300)),
                path=url_for(destination, end_cursor=end_cursor, **kwargs),
                art_dict={'thumb': 'DefaultInProgressShows.png'},
                info_dict={},
                prop_dict={'SpecialSort': 'bottom'},
            )
        )
    return programs


def convert_episode(episode, destination=None):
    """Convert paginated episode item to TitleItem"""
    import re
    import dateutil.parser
    from base64 import b64decode
    from json import loads
    import dateutil.tz

    preview = episode.get('preview', {})
    heading = preview.get('heading', {})

    title_item = TitleItem(label=None, art_dict={}, info_dict={})
    now = datetime.now(dateutil.tz.gettz('Europe/Brussels'))

    # Defaults
    path = None
    duration = timedelta(seconds=0)
    start_dt = stop_dt = None
    program_type = None
    favorited = False
    plot = ''
    geoblocked = None
    product_placement = None
    mpaa = None
    offtime = None
    permalink = None

    # Basic tile properties
    is_playable = episode.get('available', True)
    is_live = episode.get('active', False)

    # Warnings TODO: kwGeweld, kwAngst
    product_placement = next((True for item in heading.get('tertiaryMeta', []) or [] if item.get('value') == 'kwProductPlacement'), False)
    mpaa = next((item.get('longValue') for item in heading.get('tertiaryMeta', []) or [] if item.get('value').startswith('kwAge')), '')
    geoblocked = next((True for item in heading.get('tertiaryMeta', []) or [] if item.get('value') == 'kwEurope'), False)

    # Episode and program title
    program_title = heading.get('title')
    episode_title = heading.get('description')

    # Actions
    actions = actions = episode.get('actionItems') or []

    # Check favorite
    favorite_action = next(
        (item.get('action') for item in actions if item.get('action', {}).get('__typename', {}) == 'FavoriteAction'), {})
    if favorite_action:
        favorited = favorite_action.get('favorite')
    else:
        listdelete_action = next(
            (item.get('action') for item in actions if item.get('action', {}).get('__typename', {}) == 'ListDeleteAction'), {})
        favorited = bool(listdelete_action.get('listName', '').split('|')[-1] == 'live/vrtmax/favorites%')

    # Context menu
    context_menu = get_context_menu(actions)

    if not episode_title:
        actions = episode.get('actionItems') or []
        for action in actions:
            action_data = action.get('action') or {}
            if action_data.get('__typename') in {'FavoriteAction', 'ListDeleteAction'}:
                episode_title = action_data.get('title', '')
                break

    if not episode_title and destination != 'tvguide':
        episode_title = episode.get('title')

    title = episode.get('title')

    # Program Title in EPG
    if episode_title != title:
        program_title = title
    else:
        meta = loads(episode.get('trackingData', {}).get('data', '{}'))
        program_title = meta.get('$leti')

    # Path
    if episode.get('action'):
        path = url_for('play_url', video_url=episode.get('action', {}).get('link'))
    if episode.get('player'):
        stream_id = next(
            (mode.get('streamId')
             for mode in episode.get('player', {}).get('modes', [])
             if mode.get('__typename') == 'VideoPlayerMode'),
            ''
        )
        path = url_for('play_id', video_id=stream_id.split('$')[1], publication_id=stream_id.split('$')[0])

    # Duration
    progress = episode.get('progress') or {}
    status_meta = episode.get("statusMeta") or []
    status = next((item.get("value") for item in status_meta), None)
    # status = next((item.get('value') for item in episode.get('statusMeta', [])), None) gives error if statusMeta is None
    alt_status = ((episode.get('status') or {}).get('text') or {}).get('default', '')
    text = status or alt_status
    seconds = progress.get('durationInSeconds')

    if isinstance(seconds, (int, float)):
        duration = timedelta(seconds=seconds)
    else:
        minutes = (
            int(text.split()[0])
            if text.split() and text.split()[0].isdigit()
            else 0
        )
        duration = timedelta(minutes=minutes)

    # Resumepoints
    position = progress.get('progressInSeconds', 0)
    total = progress.get('durationInSeconds', 0)
    prop_dict = {}
    playcount = -1

    if resumepoints_is_activated() and position and total:
        if RESUMEPOINTS_MARGIN < position < total - RESUMEPOINTS_MARGIN:
            prop_dict.update({'resumetime': position, 'totaltime': total})
        if position > total - RESUMEPOINTS_MARGIN:
            playcount = 1

    title_item.info_dict['playcount'] = playcount
    title_item.prop_dict = prop_dict

    # Season and episode numbers
    season_no = episode_no = None

    if episode.get('primaryMeta'):
        for item in episode.get('primaryMeta', []):
            value = item.get('longValue', '') or item.get('value', '') or ''
            match = re.search(r'\d+', value)
            if not match:
                continue

            number = int(match.group())

            if 'Seizoen' in value:
                season_no = number
            elif 'Aflevering' in value:
                episode_no = number

    if not season_no:
        raw = episode.get('trackingData', {}).get('data', {})
        if isinstance(raw, str):
            meta = loads(raw)
        else:
            meta = raw
        tapu = meta.get('$tapu', '')
        parts = tapu.split("/")
        log(2, f'tapu is {tapu}, parts is {parts}')
        value = parts[4] if len(parts) > 4 else ""
        m = re.search(r'(\d+)', value)
        season_no = int(m.group(1)) if m else None

    if season_no and episode_no:
        title_item.info_dict['episode'] = episode_no
        title_item.info_dict['season'] = season_no
        program_type = 'series'

    # Aired
    # NOTE: Avoid datetime.strptime() — on some Kodi/embedded Python builds
    # (e.g. LibreELEC) it raises TypeError: 'NoneType' object is not callable.
    dutch_months = [
        'januari', 'februari', 'maart', 'april', 'mei', 'juni',
        'juli', 'augustus', 'september', 'oktober', 'november', 'december'
    ]
    aired = next(
        (meta.get('shortValue') for meta in episode.get('primaryMeta', []) or []
         if any(month in (meta.get('longValue') or '') for month in dutch_months)),
        None
    )
    if aired:
        parts = aired.split()
        date_part = parts[1] if len(parts) > 1 else parts[0]
        # shortValue is typically "zo 15/11" or "zo 15/11/2026"
        if date_part.count('/') == 1:
            date_part = f'{date_part}/{now.year}'
        try:
            start_dt = dateutil.parser.parse(date_part, dayfirst=True)
            title_item.info_dict['aired'] = start_dt.strftime('%Y-%m-%d')
            program_type = 'daily'
        except (ValueError, TypeError, OverflowError):
            log(2, "Failed to parse aired date from '{aired}'", aired=aired)

    # Art
    thumb = ''
    poster = ''
    banner = ''
    fanart = ''
    thumb_img = episode.get('image')
    if thumb_img:
        thumb = reformat_image_url(thumb_img.get('templateUrl'))
    banner_img = heading.get('titleArt')
    if banner_img:
        banner = reformat_image_url(banner_img.get('templateUrl'))
    fanart_img = heading.get('image')
    if fanart_img:
        fanart = reformat_image_url(fanart_img.get('templateUrl'))

    title_item.art_dict['thumb'] = thumb
    title_item.art_dict['poster'] = poster
    title_item.art_dict['banner'] = banner
    title_item.art_dict['fanart'] = fanart

    # EPG entries
    if episode.get('indexMeta'):
        program_type = 'epg'
        if episode.get('tileType') == 'livestream':
            is_live = True
            is_playable = True
            channel = episode.get('brand')
            start_time = episode.get('status').get('text').get('small').split(' - ')[0]
            hours, minutes = map(int, start_time.split(':'))
            dt = now.replace(hour=hours, minute=minutes, second=0, microsecond=0)
            start_ts = dt.replace(tzinfo=None).timestamp()
        else:
            comp_id = episode.get('componentId', '').lstrip('#')
            decoded = b64decode(comp_id.encode('utf-8')).decode('utf-8')
            epg_parts = decoded.split('#10')
            channel_id, start_ts = epg_parts[1], int(epg_parts[2].split('#13')[1]) / 1000
            channel = find_entry(CHANNELS, 'id', channel_id).get('name')

        start_dt = datetime.fromtimestamp(start_ts, tz=dateutil.tz.UTC)
        stop_dt = start_dt + duration

        # Fix unplayable episodes
        if not is_playable:
            # Play episode from past 24h livestream cache
            if now - timedelta(hours=LIVESTREAM_CACHE_HOURS) <= start_dt <= now:
                is_playable = True
                start_iso = start_dt.astimezone(dateutil.tz.gettz('Europe/Brussels')).isoformat()[:19]
                stop_iso = stop_dt.astimezone(dateutil.tz.gettz('Europe/Brussels')).isoformat()[:19]
                path = url_for('play_air_date', channel, start_iso, stop_iso)
            else:
                path = url_for('noop')
        # Play livestream
        elif is_live:
            path = url_for('play_url', episode['action']['link'])

    # Mark mixed episode categories
    if destination in ('recent', 'favorites_recent', 'favorites_episodes', 'resumepoints_continue', 'featured', 'search_query'):
        program_type = 'mixed_episodes'

    # Final formatting
    plot = format_plot(plot, geoblocked, product_placement, mpaa, program_type, start_dt, stop_dt, offtime, permalink)
    title_item.info_dict['plot'] = plot
    title_item.path = path

    # Label
    label = format_label(program_title, episode_title, program_type, start_dt, favorited,
                         is_playable=is_playable, is_live=is_live)

    title_item.label = label
    title_item.info_dict['title'] = label
    title_item.info_dict['tvshowtitle'] = program_title
    title_item.info_dict['mediatype'] = 'episode'
    title_item.info_dict['duration'] = duration.total_seconds()
    title_item.is_playable = is_playable
    title_item.context_menu = context_menu

    # Sorting
    sort, ascending = get_sort(program_type)
    return sort, ascending, favorited, title_item


def convert_episodes(item_list, destination, end_cursor='', use_favorites=False, **kwargs):
    """Convert paginated episode list to TitleItems"""
    episodes = []
    sort = 'unsorted'
    ascending = True

    if item_list:

        for item in item_list:
            episode = item.get('node') or item

            sort, ascending, favorited, title_item = convert_episode(episode, destination)

            # Filter favorites for favorites menu
            if use_favorites and favorited is False:
                continue

            episodes.append(title_item)

        # Paging
        # Remove kwargs with None value
        kwargs = {k: v for k, v in list(kwargs.items()) if v is not None}

        if end_cursor:
            # Add 'More...' entry at the end
            episodes.append(
                TitleItem(
                    label=colour(localize(30300)),
                    path=url_for(destination, end_cursor=quote(end_cursor, safe=''), **kwargs),
                    art_dict={'thumb': 'DefaultInProgressShows.png'},
                    info_dict={},
                    prop_dict={'SpecialSort': 'bottom'},
                )
            )

    return episodes, sort, ascending


def get_single_episode(episode_id):
    """Get single episode"""
    title_item = None
    episode = get_stream_data(episode_id).get('data').get('page')
    if episode is not None:
        _, _, _, title_item = convert_episode(episode)
    return title_item


def get_latest_episode(program_name):
    """Get the latest episode of a program"""
    latest_episode = {}
    video = None
    latest_episode = get_latest_episode_data(program_name=program_name)
    if latest_episode:
        _, _, _, title_item = convert_episode(latest_episode)
        video = {
            'listitem': title_item,
            'video_id': title_item.path.split('/')[5],
            'publication_id': title_item.path.split('/')[6]
        }
    return video


def get_offline_programs(end_cursor='', use_favorites=False):
    """Get laatste kans/soon offline programs"""
    from base64 import b64encode
    list_id = 'o%35|p%/|list_1624607593_copy_1408213323|b%0|n%1%'
    list_id = f'${b64encode(list_id.encode("utf-8")).decode("utf-8")}'
    destination = 'favorites_offline' if use_favorites else 'offline'
    programs = get_programs(list_id=list_id, destination=destination, end_cursor=end_cursor, use_favorites=use_favorites)
    return programs


def get_favorite_programs(end_cursor=''):
    """Get favorite programs"""
    from base64 import b64encode
    list_id = 'o%25|o%9|video-program|o%504|%%|video-program|b%0%'
    list_id = f'${b64encode(list_id.encode("utf-8")).decode("utf-8")}'
    programs = get_programs(list_id=list_id, destination='favorites_programs', end_cursor=end_cursor)
    return programs


def get_favorite_episodes(end_cursor=''):
    """Get favorite episodes"""
    import base64
    list_id = 'o%25|o%9|video-episode|p%/mijn-lijst/?entityType=video-episode%|video-episode|b%0%'
    list_id = '${}'.format(base64.b64encode(list_id.encode('utf-8')).decode('utf-8'))
    episodes, sort, ascending, content = get_episodes(list_id=list_id, destination='favorites_episodes', end_cursor=end_cursor)
    return episodes, sort, ascending, content


def get_featured(feature=None, end_cursor=''):
    """Get featured menu items"""
    content = 'files'
    sort = 'unsorted'
    ascending = True
    if feature:
        if feature.startswith('program_'):
            list_id = feature.replace('_proto_', ':/').split('program_')[1]
            programs = get_programs(list_id=list_id, destination='featured', end_cursor=end_cursor, feature=feature)
            return programs, sort, ascending, 'tvshows'

        if feature.startswith('episode_'):
            list_id = feature.replace('_proto_', ':/').split('episode_')[1]
            episodes, sort, ascending, content = get_episodes(list_id=list_id, destination='featured', end_cursor=end_cursor, feature=feature)
            return episodes, sort, ascending, content
    else:
        featured = []
        featured_json = get_featured_data()
        for edge in featured_json.get('data').get('page').get('paginatedComponents').get('edges'):
            node = edge.get('node')
            content_type = node.get('tileContentType')
            if content_type in ('program', 'episode'):
                title = (
                    (node.get('title') or '').strip()
                    or (node.get('banner', {}).get('title') or '').strip()
                    or (node.get('header', {}).get('description') or '').strip()
                )
                feature_id = node.get('listId').replace(':/', '_proto_')
                featured.append(
                    TitleItem(
                        label=title,
                        path=url_for('featured', feature='{}_{}'.format(content_type, feature_id)),
                        art_dict={'thumb': 'DefaultCountry.png'},
                        info_dict={
                            'title': title,
                            'plot': '[B]%s[/B]' % title,
                            'studio': 'VRT',
                            'mediatype': 'season',
                        },
                        is_playable=False,
                    )
                )
    return featured, sort, ascending, content


def get_search(keywords, end_cursor=''):
    """Get search items"""
    items = []
    if not end_cursor:
        items.extend(get_programs(keywords=keywords))
    list_id = get_search_list_id(keywords=keywords, content_type='episode')
    if list_id:
        episodes, _, _, _, = get_episodes(list_id=list_id, destination='search_query', end_cursor=end_cursor, keywords=keywords)
        items.extend(episodes)
    return items


def get_search_list_id(keywords=None, facets=None, content_type='program'):
    """Get the list id of a search page."""
    from json import dumps
    query = []
    if keywords:
        query.append('q={}'.format(quote(keywords, safe='')))
    if facets:
        query.append('facets={}'.format(quote(dumps(facets, separators=(',', ':')), safe='')))
    page_id = '/vrtmax/zoeken/?{}'.format('&'.join(query)) if query else '/vrtmax/zoeken/'
    graphql_query = """
        query SearchPage($pageId: ID!) {
          page(id: $pageId) {
            ... on SearchResultPage {
              components {
                ... on PaginatedTileList {
                  listId
                  tileContentType
                }
                ... on ContainerNavigation {
                  items {
                    components {
                      ... on PaginatedTileList {
                        listId
                        tileContentType
                      }
                    }
                  }
                }
              }
            }
          }
        }
    """
    data_json = api_req(graphql_query, 'SearchPage', {'pageId': page_id})
    components = ((data_json.get('data') or {}).get('page') or {}).get('components') or []
    for component in components:
        nested = [comp for item in component.get('items') or [] for comp in item.get('components') or []]
        for comp in [component] + nested:
            if comp.get('tileContentType') == content_type:
                return comp.get('listId')
    return None


def get_programs(list_id=None, destination=None, end_cursor='', category=None, channel=None, keywords=None, feature=None, use_favorites=False):
    """Get programs"""

    if not list_id:
        facets = []
        if category:
            facet_name = 'genre'
            # VRT MAX uses 'contenttype' facet name instead of 'genre' for some categories
            if category in ('docu', 'films', 'series', 'talkshows'):
                facet_name = 'contenttype'
            destination = 'categories'
            facets.append({
                'name': facet_name,
                'values': [category],
            })
        elif channel:
            destination = 'channels'
            facets.append({
                'name': 'brand',
                'values': [channel]
            })
        elif keywords:
            destination = 'search_query'
        list_id = get_search_list_id(keywords=keywords, facets=facets, content_type='program')
        if not list_id:
            return []

    # kodi paging
    kodi_page_size = get_setting_int('itemsperpage', default=50)
    fetched = 0
    item_list = []
    while fetched < kodi_page_size:
        page_size = kodi_page_size - fetched
        api_data = get_entities(list_id=list_id, page_size=page_size, end_cursor=end_cursor)
        paginated = api_data.get('data', {}).get('list', {}).get('paginatedItems', {})
        edges = paginated.get('edges', [])
        page_info = paginated.get('pageInfo', {})
        item_list.extend(edges)
        fetched += len(edges)
        if not page_info.get('hasNextPage'):
            end_cursor = ''
            break
        end_cursor = page_info.get('endCursor')

    programs = convert_programs(item_list, destination=destination, end_cursor=end_cursor, category=category,
                                channel=channel, feature=feature, keywords=keywords, use_favorites=use_favorites)
    return programs


def get_continue_episodes(end_cursor=''):
    """Get continue episodes"""
    from base64 import b64encode
    list_id = 'o%35|p%/|list_1744022689|b%0%'
    list_id = f'${b64encode(list_id.encode("utf-8")).decode("utf-8")}'
    destination = 'resumepoints_continue'
    episodes, sort, ascending, content = get_episodes(list_id=list_id, destination=destination, end_cursor=end_cursor)
    return episodes, sort, ascending, content


def get_recent_episodes(end_cursor='', use_favorites=False):
    """Get recent episodes"""
    from base64 import b64encode
    list_id = 'o%35|p%/kijk/|list_copy_copy_copy|b%0|n%1%'
    list_id = f'${b64encode(list_id.encode("utf-8")).decode("utf-8")}'
    destination = 'favorites_recent' if use_favorites else 'recent'
    episodes, sort, ascending, content = get_episodes(list_id=list_id, destination=destination, end_cursor=end_cursor)
    return episodes, sort, ascending, content


def get_episodes(list_id=None, destination=None, end_cursor='', program_name=None, use_favorites=False,
                 feature=None, keywords=None, date=None, channel=None):
    """Get episodes"""
    sort = 'unsorted'
    ascending = True
    content = 'files'

    if not list_id:
        # Check for multiple seasons
        api_data = get_seasons(program_name)
        seasons = convert_seasons(api_data, program_name)
        if len(seasons) == 1 and seasons[0].path.startswith('plugin://plugin.video.vrt.nu.htpc/programs/'):
            path = seasons[0].path
            log(2, 'Single season with path {path}', path=path)
            program_name = path.split('/')[-2]
            list_id = path.split('/')[-1]
        else:
            return seasons, sort, ascending, content

    # kodi paging
    kodi_page_size = get_setting_int('itemsperpage', default=50)
    fetched = 0
    item_list = []
    while fetched < kodi_page_size:
        page_size = kodi_page_size - fetched
        api_data = get_entities(list_id=list_id, page_size=page_size, end_cursor=end_cursor)
        paginated = ((api_data.get('data') or {}).get('list') or {}).get('paginatedItems', {})
        edges = paginated.get('edges', [])
        page_info = paginated.get('pageInfo', {})
        item_list.extend(edges)
        fetched += len(edges)
        if not page_info.get('hasNextPage'):
            end_cursor = ''
            break
        end_cursor = page_info.get('endCursor')

    episodes, sort, ascending = convert_episodes(item_list, destination=destination, end_cursor=end_cursor, use_favorites=use_favorites,
                                                 program_name=program_name, list_id=list_id, feature=feature, keywords=keywords,
                                                 date=date, channel=channel)
    return episodes, sort, ascending, 'episodes'


def convert_seasons(api_data, program_name):
    """Convert seasons"""
    seasons = []
    for season in api_data:
        if season.get('path'):
            episode_tile = season.get('episode_tile')
            if not episode_tile:
                episode_tile = get_stream_data(season.get('path')).get('data', {}).get('page', {})
            _, _, _, title_item = convert_episode(episode_tile)
            if len(api_data) > 1:
                season_title = '[B]{}:[/B] {}'.format(season.get('title'), title_item.label)
            elif title_item.info_dict['tvshowtitle'] and title_item.info_dict['tvshowtitle'] != title_item.label:
                season_title = '[B]{}:[/B] {}'.format(title_item.info_dict['tvshowtitle'], title_item.label)
            else:
                season_title = title_item.label

            title_item.label = season_title
            title_item.info_dict['title'] = season_title
            seasons.append(title_item)

        elif season.get('list_id'):
            season_title = season.get('title')
            path = url_for('programs', program_name=program_name, list_id=season.get('list_id'))
            seasons.append(
                TitleItem(
                    label=season_title,
                    path=path,
                    info_dict={
                        'title': season_title,
                        'mediatype': 'season',
                    },
                    is_playable=False,
                )
            )
    return seasons


def get_seasons(program_name):
    """Fetch seasons for a program, return list of dicts with title, episode, and either path or list_id."""
    data = get_seasons_data(program_name)
    page = (data.get('data') or {}).get('page', {})
    menu = page.get('menu', {})

    seasons = []

    for nav_item in menu.get('items', []):
        nav_title = nav_item.get('title')
        for comp in nav_item.get('components', []):
            typename = comp.get('__typename')
            if typename == 'ContainerNavigation':
                for inner in comp.get('items', []):
                    components = inner.get('components', [])
                    list_id = next(
                        (c.get('listId') for c in components if c.get('listId')),
                        None,
                    )
                    episode_tile = next(
                        (
                            edge.get('node', {})
                            for c in components
                            for edge in c.get('paginatedItems', {}).get('edges', [])
                            if edge.get('node', {}).get('__typename') == 'EpisodeTile'
                        ),
                        None,
                    )
                    entry = {
                        'title': inner.get('title'),
                        'list_id': list_id,
                    }
                    if episode_tile:
                        entry['episode_tile'] = episode_tile

                    seasons.append(entry)
                continue

            if typename != 'PaginatedTileList':
                continue

            content_type = comp.get('tileContentType')
            if content_type not in ('episode', 'program'):
                continue

            edges = comp.get('paginatedItems', {}).get('edges', [])
            episode_tile = next(
                (
                    edge.get('node', {})
                    for edge in edges
                    if edge.get('node', {}).get('__typename') == 'EpisodeTile'
                ),
                None,
            )

            entry = {
                'title': nav_title,
                'list_id': comp.get('listId'),
            }

            if len(edges) == 1 and content_type == 'episode':
                action = edges[0].get('node', {}).get('action', {})
                if action.get('__typename') == 'LinkAction':
                    entry = {
                        'title': nav_title,
                        'path': action.get('link'),
                    }
            if episode_tile:
                entry['episode_tile'] = episode_tile

            seasons.append(entry)

    # Prepend most relevant episode if no entries or more than one entry
    if not seasons or len(seasons) > 1:
        header = page.get('header', {})
        for item in header.get('actionItems', []):
            action = item.get('action', {})
            if action.get('__typename') != 'LinkAction':
                continue

            path = action.get('link')

            if not any(s.get('path') == path for s in seasons):
                seasons.insert(0, {
                    'title': item.get('title'),
                    'path': path,
                })

            break

    return seasons


def api_req(graphql_query, operation_name, variables, client='WEB'):
    """GraphQL API Request"""
    from json import dumps
    from tokenresolver import TokenResolver
    access_token = TokenResolver().get_token('vrtnu-site_profile_at')
    data_json = {}
    if access_token:
        payload = {
            'operationName': operation_name,
            'query': graphql_query,
            'variables': variables,
        }
        data = dumps(payload).encode('utf-8')
        headers = {
            'Accept': 'application/json',
            'Authorization': 'Bearer ' + access_token,
            'Content-Type': 'application/json',
            'x-vrt-client-name': client,
            'x-vrt-client-version': '1.5.15',
        }
        data_json = get_url_json(url=GRAPHQL_URL, cache=None, headers=headers, data=data)
        if data_json.get('errors'):
            log_error(dumps(data_json, indent=2))
    return data_json


def get_featured_data():
    """Get featured data"""
    graphql_query = """
        query Page(
          $pageId: ID!
          $lazyItemCount: Int = 10
          $after: ID
          $before: ID
          $componentCount: Int = 5
          $componentAfter: ID
        ) {
          page(id: $pageId) {
            ... on IPage {
              title
              permalink
              paginatedComponents(first: $componentCount, after: $componentAfter) {
                __typename
                edges {
                  __typename
                  node {
                    ... on PaginatedTileList {
                      __typename
                      listId
                      componentType
                      paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
                        __typename
                        edges {
                          __typename
                          node {
                            __typename
                          }
                        }
                      }
                      banner {
                        title
                      }
                      tileContentType
                      title
                      __typename
                    }
                    ... on StaticTileList {
                      __typename
                      banner {
                        title
                      }
                      listId
                      title
                      componentType
                      tileContentType
                    }
                    __typename
                  }
                }
              }
            }
          }
        }
    """
    operation_name = 'Page'
    variables = {
        'pageId': '/vrtmax/',
        'pageContext': {
            'mediaType': 'watch'
        },
        'componentAfter': '',
        'componentCount': 50,
    }
    return api_req(graphql_query, operation_name, variables)


def get_categories_data():
    """Return a list of categories"""
    cache_file = 'categories.json'

    # Try the cache if it is fresh
    categories = get_cache(cache_file, ttl=7 * 24 * 60 * 60)
    if valid_categories(categories):
        return categories

    # Try online categories json
    categories = get_online_categories()
    if valid_categories(categories):
        from json import dumps
        update_cache(cache_file, dumps(categories))
        return categories

    # Fall back to internal hard-coded categories
    from data import CATEGORIES
    log(2, 'Fall back to internal hard-coded categories')
    return CATEGORIES


def get_categories():
    """Get categories"""
    categories_data = get_categories_data()
    categories = []
    from data import CATEGORIES
    for category in localize_categories(categories_data, CATEGORIES):
        if get_setting_bool('showfanart', default=True):
            thumbnail = category.get('thumbnail', 'DefaultGenre.png')
        else:
            thumbnail = 'DefaultGenre.png'
        categories.append(TitleItem(
            label=category.get('name'),
            path=url_for('categories', category=category.get('id')),
            art_dict={'thumb': thumbnail, 'icon': 'DefaultGenre.png'},
            info_dict={'plot': '[B]%s[/B]' % category.get('name'), 'studio': 'VRT'},
        ))
    return categories


def get_online_categories():
    """Return a list of categories from the VRT MAX website"""
    categories = []
    graphql_query = """
        query Page(
          $pageId: ID!
          $lazyItemCount: Int = 10
          $after: ID
          $before: ID
          $componentCount: Int = 5
          $componentAfter: ID
        ) {
          page(id: $pageId) {
            ... on IIdentifiable {
              __typename
              objectId
            }
            ... on IPage {
              paginatedComponents(first: $componentCount, after: $componentAfter) {
                __typename
                edges {
                  __typename
                  node {
                    ... on PaginatedTileList {
                      __typename
                      objectId
                      listId
                      displayType
                      paginatedItems(first: $lazyItemCount, after: $after, before: $before) {
                        __typename
                        edges {
                          __typename
                          cursor
                          node {
                            __typename
                          }
                        }
                        pageInfo {
                          __typename
                          endCursor
                          hasNextPage
                          hasPreviousPage
                          startCursor
                        }
                      }
                      tileContentType
                      title
                      description
                      __typename
                    }
                    ... on StaticTileList {
                      __typename
                      objectId
                      listId
                      title
                      tileContentType
                      displayType
                      items {
                        ... on ButtonTile {
                          mode
                          title
                          id
                          objectId
                          action {
                            ... on LinkAction {
                              link
                              internalTarget
                              externalTarget
                              __typename
                            }
                          }
                          tileType
                          image {
                            templateUrl
                          }
                          __typename
                        }
                        __typename
                      }
                      __typename
                    }
                    __typename
                  }
                  __typename
                }
                __typename
              }
              __typename
            }
            __typename
          }
        }
    """
    operation_name = 'Page'
    variables = {
        'pageId': '/vrtmax/zoeken/',
    }
    categories_json = api_req(graphql_query, operation_name, variables)
    if categories_json is not None:
        from json import loads
        edges = categories_json.get('data', {}).get('page', {}).get('paginatedComponents', {}).get('edges', [])
        content_types = next(
            (
                item.get('node')
                for item in edges
                if item.get('node', {}).get('listId') == 'initialsearchcontenttypes'
            ),
            {}
        ).get('items', [])
        genres = next(
            (
                item.get('node')
                for item in edges
                if item.get('node', {}).get('listId') == 'initialsearchgenres'
            ),
            {}
        ).get('items', [])
        category_items = content_types + genres
        for category in category_items:
            # Don't add audio-only categories
            if category.get('title') in ('Podcasts', 'Radio'):
                continue
            category_id = loads(unquote(category.get('action').get('link')).split('?facets=')[1])[0].get('values')[0]
            categories.append({
                'id': category_id,
                'name': category.get('title'),
            })
        categories.sort(key=lambda x: x.get('name'))
    return categories


def valid_categories(categories):
    """Check if categories contain all necessary keys and values"""
    return bool(categories) and all(item.get('id') and item.get('name') for item in categories)


def localize_categories(categories, categories2):
    """Return a localized and sorted listing"""
    for category in categories:
        for key, val in list(category.items()):
            if key == 'name':
                category[key] = localize_from_data(val, categories2)
    return sorted(categories, key=lambda x: x.get('name'))


def get_channels(channels=None, live=True):
    """Construct a list of channel ListItems, either for Live TV or the TV Guide listing"""
    channel_items = []
    for channel in CHANNELS:
        if channels and channel.get('name') not in channels:
            continue

        context_menu = []
        art_dict = {}
        path = None

        # Try to use the white icons for thumbnails (used for icons as well)
        if has_addon('resource.images.studios.white'):
            art_dict['thumb'] = 'resource://resource.images.studios.white/{studio}.png'.format(**channel)
        else:
            art_dict['thumb'] = 'DefaultTags.png'

        if not live:
            path = url_for('channels', channel=channel.get('name'))
            label = channel.get('label')
            plot = '[B]%s[/B]' % channel.get('label')
            is_playable = False
            info_dict = {'title': label, 'plot': plot, 'studio': channel.get('studio'), 'mediatype': 'video'}
            stream_dict = []
            prop_dict = {}
        elif channel.get('live_stream') or channel.get('live_stream_id'):
            if channel.get('live_stream_id'):
                path = url_for('play_id', video_id=channel.get('live_stream_id'))
            elif channel.get('live_stream'):
                path = url_for('play_url', video_url=channel.get('live_stream'))
            label = localize(30141, **channel)  # Channel live
            # A single Live channel means it is the entry for channel's TV Show listing, so make it stand out
            if channels and len(channels) == 1:
                label = '[B]%s[/B]' % label
            is_playable = True
            if channel.get('name') in ['een', 'canvas', 'ketnet']:
                if get_setting_bool('showfanart', default=True):
                    art_dict['fanart'] = get_live_screenshot(channel.get('name', art_dict.get('fanart')))
                plot = localize(30142, **channel)
            else:
                plot = localize(30142, **channel)  # Watch live
            # NOTE: Playcount and resumetime are required to not have live streams as "Watched" and resumed
            info_dict = {'title': label, 'plot': plot, 'studio': channel.get('studio'), 'mediatype': 'video', 'playcount': 0, 'duration': 0}
            prop_dict = {'resumetime': 0}
            stream_dict = {'duration': 0}
            context_menu.append((
                localize(30413),  # Refresh menu
                'RunPlugin(%s)' % url_for('delete_cache', cache_file='channel.{channel}.json'.format(channel=channel)),
            ))
        else:
            # Not a playable channel
            continue

        channel_items.append(TitleItem(
            label=label,
            path=path,
            art_dict=art_dict,
            info_dict=info_dict,
            prop_dict=prop_dict,
            stream_dict=stream_dict,
            context_menu=context_menu,
            is_playable=is_playable,
        ))

    return channel_items


def get_youtube(channels=None):
    """Construct a list of youtube ListItems, either for Live TV or the TV Guide listing"""

    youtube_items = []

    if not has_addon('plugin.video.youtube') or not get_setting_bool('showyoutube', default=True):
        return youtube_items

    for channel in CHANNELS:
        if channels and channel.get('name') not in channels:
            continue

        art_dict = {}

        # Try to use the white icons for thumbnails (used for icons as well)
        if has_addon('resource.images.studios.white'):
            art_dict['thumb'] = 'resource://resource.images.studios.white/{studio}.png'.format(**channel)
        else:
            art_dict['thumb'] = 'DefaultTags.png'

        for youtube in channel.get('youtube', []):
            path = youtube_to_plugin_url(youtube['url'])
            label = localize(30143, **youtube)  # Channel on YouTube
            # A single Live channel means it is the entry for channel's TV Show listing, so make it stand out
            if channels and len(channels) == 1:
                label = '[B]%s[/B]' % label
            plot = localize(30144, **youtube)  # Watch on YouTube
            # NOTE: Playcount is required to not have live streams as "Watched"
            info_dict = {'title': label, 'plot': plot, 'studio': channel.get('studio'), 'mediatype': 'video', 'playcount': 0}

            context_menu = [(
                localize(30413),  # Refresh menu
                'RunPlugin(%s)' % url_for('delete_cache', cache_file='channel.{channel}.json'.format(channel=channel)),
            )]

            youtube_items.append(TitleItem(
                label=label,
                path=path,
                art_dict=art_dict,
                info_dict=info_dict,
                context_menu=context_menu,
                is_playable=False,
            ))

    return youtube_items


def get_live_screenshot(channel):
    """Get a live screenshot for a given channel, only supports VRT 1, Canvas and Ketnet"""
    url = '%s/%s.jpg' % (SCREENSHOT_URL, channel)
    delete_cached_thumbnail(url)
    return url
