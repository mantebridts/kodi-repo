# -*- coding: utf-8 -*-
""" VTM GO API """

from __future__ import absolute_import, division, unicode_literals

import json
import logging

from resources.lib import kodiutils
from resources.lib.vtmgo import API_ANDROID_ENDPOINT, API_ENDPOINT, Category, Episode, LiveChannel, LiveChannelEpg, Movie, Program, Season, util, Teaser

_LOGGER = logging.getLogger(__name__)

try:  # Python 3
    from urllib.parse import quote
except ImportError:  # Python 2
    from urllib import quote

CACHE_AUTO = 1  # Allow to use the cache, and query the API if no cache is available
CACHE_ONLY = 2  # Only use the cache, don't use the API
CACHE_PREVENT = 3  # Don't use the cache

CONTENT_TYPE_MOVIE = 'MOVIE'
CONTENT_TYPE_PROGRAM = 'PROGRAM'
CONTENT_TYPE_EPISODE = 'EPISODE'


class ApiUpdateRequired(Exception):
    """ Is thrown when an API update is required. """


class VtmGo:
    """ VTM GO API """

    def __init__(self, tokens):
        """ Initialise object
        :param resources.lib.vtmgo.vtmgoauth.AccountStorage token:       An authenticated token.
        """
        self._tokens = tokens

    def _mode(self):
        """ Return the mode that should be used for API calls """
        return 'vtmgo-kids' if self.get_product() == 'VTM_GO_KIDS' else 'VTM_GO'

    @staticmethod
    def get_config():
        """ Returns the config for the app """
        # This is currently not used
        response = util.http_get(API_ANDROID_ENDPOINT + '/vtmgo/config')
        info = json.loads(response.text)

        # This contains a player.updateIntervalSeconds that could be used to notify VTM GO about the playing progress
        return info

    def get_storefront(self, storefront):
        """ Returns a storefront.

         :param str storefront:         The ID of the storefront.
         :rtype: list[Category|Program|Movie]
         """
        response = util.http_get(API_ENDPOINT + '/%s/storefronts/%s' % (self._mode(), storefront),
                                 token=self._tokens.access_token if self._tokens else None,
                                 profile=self._tokens.profile if self._tokens else None)
        result = json.loads(response.text)

        items = []
        for row in result.get('rows', []):
            _LOGGER.debug('Get storefront %s with type %s', row.get('title'), row.get('rowType'))
            if row.get('rowType') in ['SWIMLANE_DEFAULT', 'SWIMLANE_PORTRAIT', 'SWIMLANE_LANDSCAPE', 'CONTINUE_WATCHING', 'SWIMLANE_TOP10']:
                items.append(Category(
                    category_id=row.get('id'),
                    title=row.get('title').strip(),
                ))
                continue

            if row.get('rowType') == 'CAROUSEL':
                for item in row.get('teasers'):
                    items.append(self._parse_teaser(item))
                    # if item.get('target', {}).get('type') == CONTENT_TYPE_MOVIE:
                    #     items.append(self._parse_movie_teaser(item))
                    #
                    # elif item.get('target', {}).get('type') == CONTENT_TYPE_PROGRAM:
                    #     items.append(self._parse_program_teaser(item))
                continue

            if row.get('rowType') in ['TOP_BANNER', 'MARKETING_BLOCK']:
                item = row.get('teaser')
                items.append(self._parse_detail_teaser(item))
                # if item.get('target', {}).get('type') == CONTENT_TYPE_MOVIE:
                #     items.append(self._parse_movie_teaser(item))
                #
                # elif item.get('target', {}).get('type') == CONTENT_TYPE_PROGRAM:
                #     items.append(self._parse_program_teaser(item))
                continue

            _LOGGER.debug('Skipping recommendation %s with type %s', row.get('title'), row.get('rowType'))

        return items

    def get_storefront_category(self, storefront, category):
        """ Returns a storefront.

         :param str storefront:         The ID of the storefront.
         :param str category:           The ID of the category.
         :rtype: Category
         """
        response = util.http_get(API_ENDPOINT + '/%s/storefronts/%s/detail/%s' % (self._mode(), storefront, category),
                                 token=self._tokens.access_token if self._tokens else None,
                                 profile=self._tokens.profile if self._tokens else None)
        result = json.loads(response.text)

        items = []
        for item in result.get('row', {}).get('teasers'):
            items.append(self._parse_teaser(item))
            # if item.get('target', {}).get('type') == CONTENT_TYPE_MOVIE:
            #     items.append(self._parse_movie_teaser(item))
            #
            # elif item.get('target', {}).get('type') == CONTENT_TYPE_PROGRAM:
            #     items.append(self._parse_program_teaser(item))

        return Category(category_id=category, title=result.get('row', {}).get('title'), content=items)

    def get_mylist(self, content_filter=None, cache=CACHE_ONLY):
        """ Returns the contents of My List """
        response = util.http_get(API_ENDPOINT + '/%s/my-list' % (self._mode()),
                                 token=self._tokens.access_token if self._tokens else None,
                                 profile=self._tokens.profile if self._tokens else None)

        # Result can be empty
        if not response.text:
            return []

        result = json.loads(response.text)

        items = []
        for item in result.get('teasers', []):
            items.append(self._parse_teaser(item))
            # if item.get('target', {}).get('type') == CONTENT_TYPE_MOVIE and content_filter in [None, Movie]:
            #     items.append(self._parse_movie_teaser(item, cache=cache))
            #
            # elif item.get('target', {}).get('type') == CONTENT_TYPE_PROGRAM and content_filter in [None, Program]:
            #     items.append(self._parse_program_teaser(item, cache=cache))
            #
            # elif item.get('target', {}).get('type') == CONTENT_TYPE_EPISODE and content_filter in [None, Episode]:
            #     items.append(self._parse_episode_teaser(item, cache=cache))

        return items

    def add_mylist(self, content_id):
        """ Add an item to My List """
        util.http_put(API_ENDPOINT + '/%s/userData/myList/%s' % (self._mode(), content_id),
                      token=self._tokens.access_token,
                      profile=self._tokens.profile)
        kodiutils.set_cache(['swimlane', 'my-list'], None)

    def del_mylist(self, content_id):
        """ Delete an item from My List """
        util.http_delete(API_ENDPOINT + '/%s/userData/myList/%s' % (self._mode(), content_id),
                         token=self._tokens.access_token,
                         profile=self._tokens.profile)
        kodiutils.set_cache(['swimlane', 'my-list'], None)

    def get_live_channels(self):
        """ Get a list of all the live tv channels.
        :rtype list[LiveChannel]
        """
        import dateutil.parser
        response = util.http_get(API_ENDPOINT + '/%s/live' % self._mode(),
                                 token=self._tokens.access_token if self._tokens else None,
                                 profile=self._tokens.profile if self._tokens else None)
        info = json.loads(response.text)

        channels = []
        for item in info.get('channels'):
            epg = []
            for item_epg in item.get('broadcasts', []):
                epg.append(LiveChannelEpg(
                    title=item_epg.get('title')['label'], # New from API26
                    start=dateutil.parser.parse(item_epg.get('startsAt')),
                    end=dateutil.parser.parse(item_epg.get('endsAt')),
                ))
            channels.append(LiveChannel(
                key=item.get('seoKey'),
                channel_id=item.get('channelId'),
                logo=item.get('channelLogoUrl'),
                background=item.get('backgroundImageUrl'),  # new from API26 
                name=item.get('name'),
                epg=epg,
            ))

        return channels

    def get_live_channel(self, key):
        """ Get a the specified live tv channel.
        :rtype LiveChannel
        """
        channels = self.get_live_channels()
        return next(c for c in channels if c.key == key)

    def get_playableId(self, uuid=None, category=None):
        """ Get the playable id for the specified uuid from tvguide
        :rtype str
        """
        playableId=None
        if uuid:
            response = util.http_get(API_ENDPOINT + '/%s/live/broadcast/%s' % (self._mode(), uuid),
                                    token=self._tokens.access_token if self._tokens else None,
                                    profile=self._tokens.profile if self._tokens else None)
            info = json.loads(response.text)
            detailId=info.get('detailId')
            episodeTitle=info.get('episodeTitle')
            if detailId:
                response = util.http_get(API_ENDPOINT + '/%s/detail3/%s' % (self._mode(), detailId),
                                        token=self._tokens.access_token if self._tokens else None,
                                        profile=self._tokens.profile if self._tokens else None)
                info = json.loads(response.text)
                if category=='episodes':
                    playableId = next(
                        (
                        ep["id"]
                        for ep in info["seasonPicker"]["selected"]["episodes"]
                        if ep["title"].split(". ", 1)[1] == episodeTitle
                        ),
                        None
                        )
                else:
                    playableId = (info.get("primaryButton") or {}).get("playableId")
                    
        return playableId

    def get_detail(self, detail_id, cache=CACHE_AUTO):
        """ Get the details of the specified program.
        :type detail_id: str
        :type cache: int
        :rtype Program
        """
        if cache in [CACHE_AUTO, CACHE_ONLY]:
            # Try to fetch from cache
            detail = kodiutils.get_cache(['detail', detail_id])
            if detail is None and cache == CACHE_ONLY:
                return None
        else:
            detail = None

        if not detail:
            # Fetch from API / 20251014 detail3
            response = util.http_get(API_ENDPOINT + '/%s/detail3/%s' % (self._mode(), detail_id),
                                     token=self._tokens.access_token if self._tokens else None,
                                     profile=self._tokens.profile if self._tokens else None)
            detail = json.loads(response.text)
            kodiutils.set_cache(['detail', detail_id], detail)

        # channel = self._parse_channel(detail.get('channelLogoUrl'))

#        if detail.get('selectedSeason') is None: / 20251014 
        if detail.get('seasonPicker') is None:
            # Movie
            movie = detail
            secbut= (movie.get('secondaryButtons') or [{}])[0].get('priceLabel')
            warning = secbut + '\n' if secbut else ' '
            warning = f'[B][COLOR=yellow]{warning}[/COLOR][/B]'
            jaar = (movie.get('headerLabels') or [{}])[0].get('label')
            naam=movie.get('title', {}).get('label')
            if naam and '(' not in naam:
                naam = f"{naam} ({jaar})"
            return Movie(
                movie_id=movie.get('id'),
                description=warning + movie.get('description'),
                duration=movie.get('durationSeconds'),
                thumb=movie.get('landscapeTeaserImageUrl'),
                fanart=movie.get('backgroundImageUrl'),
                year=jaar,
                name=naam,
                #geoblocked=movie.get('blockedFor') == 'GEO',
                #remaining=movie.get('remainingDaysAvailable'),
                legal=movie.get('legalText'),
                # aired=movie.get('broadcastTimestamp'),
                # channel=self._parse_channel(movie.get('channelLogoUrl')),
            )

        else:
            # Program
            program = detail
            seasons = {}
#            for item_season in detail.get('seasonIndices', []): / 20251014 
            for item_season in detail.get('seasonPicker', {}).get('indices', []):
                episodes = []
                _LOGGER.debug('Loop in seasons')

                # Fetch season   / 20251014 detail3
                season_response = util.http_get(API_ENDPOINT + '/%s/detail3/%s?selectedSeasonIndex=%s' % (self._mode(), detail_id, item_season),
                                                token=self._tokens.access_token if self._tokens else None,
                                                profile=self._tokens.profile if self._tokens else None)
#                season = json.loads(season_response.text).get('selectedSeason') / 20251014 
                season = json.loads(season_response.text).get('seasonPicker', {}).get('selected')

                for item_episode in season.get('episodes', []):
                    badge = item_episode.get('badge')
                    warning = badge.get('label') + '\n' if badge else ' '
                    warning = f'[B][COLOR=yellow]{warning}[/COLOR][/B]'
                    episodes.append(Episode(
                        episode_id=item_episode.get('id'),
                        program_id=detail_id,
                        program_name=program.get('name'),
                        number=item_episode.get('index'),
                        season=item_season,
                        name=item_episode.get('title'),
                        description=warning + item_episode.get('description'),
                        duration=item_episode.get('durationSeconds'),
                        thumb=item_episode.get('imageUrl'),
                        fanart=item_episode.get('imageUrl'),
                        # aired=aired
                        # geoblocked=program.get('blockedFor') == 'GEO',
                        # remaining=item_episode.get('remainingDaysAvailable'),
                        # channel=channel,
                        # legal=program.get('legalIcons'),
                        # aired=item_episode.get('broadcastTimestamp'),                   / 20251014 
                        # progress=item_episode.get('playerPositionSeconds', 0),          / 20251014 
                        # watched=item_episode.get('doneWatching', False),                / 20251014 
                    ))

                seasons[item_season] = Season(
                    number=item_season,
                    episodes=episodes,
                    # channel=channel,
                    # legal=program.get('legalIcons'),
                )

            return Program(
                program_id=program.get('id'),
                name=program.get('name'),
                description=program.get('description'),
                thumb=program.get('landscapeTeaserImageUrl'),
                fanart=program.get('backgroundImageUrl'),
                # geoblocked=program.get('blockedFor') == 'GEO',
                seasons=seasons,
                # channel=channel,
                year = (program.get('headerLabels') or [{}])[0].get('label'),
                legal=program.get('legalText'),
                # my_list=program.get('addedToMyList'),  # Don't use addedToMyList, since we might have cached this info
            )

    def get_movie(self, movie_id, cache=CACHE_AUTO):
        """ Get the details of the specified movie.
        :type movie_id: str
        :type cache: int
        :rtype Movie
        """
        if cache in [CACHE_AUTO, CACHE_ONLY]:
            # Try to fetch from cache
            movie = kodiutils.get_cache(['movie', movie_id])
            if movie is None and cache == CACHE_ONLY:
                return None
        else:
            movie = None

        if not movie:
            # Fetch from API
            response = util.http_get(API_ENDPOINT + '/%s/detail3/%s' % (self._mode(), movie_id),
                                     token=self._tokens.access_token if self._tokens else None,
                                     profile=self._tokens.profile if self._tokens else None)
            movie = json.loads(response.text)
            kodiutils.set_cache(['movie', movie_id], movie)
 
        secbut= (movie.get('secondaryButtons') or [{}])[0].get('priceLabel')
        warning = secbut + '\n' if secbut else ' '
        warning = f'[B][COLOR=yellow]{warning}[/COLOR][/B]'
        jaar = (movie.get('headerLabels') or [{}])[0].get('label')
        naam=movie.get('title', {}).get('label')
        if naam and '(' not in naam:
            naam = f"{naam} ({jaar})"
        return Movie(
            movie_id=movie.get('id'),
            description=warning + movie.get('description'),
            duration=movie.get('durationSeconds'),
            thumb=movie.get('landscapeTeaserImageUrl'),
            fanart=movie.get('backgroundImageUrl'),
            year=jaar,
            name=naam,
            #geoblocked=movie.get('blockedFor') == 'GEO',store
            #remaining=movie.get('remainingDaysAvailable'),
            legal=movie.get('legalText'),
            # aired=movie.get('broadcastTimestamp'),
            # channel=self._parse_channel(movie.get('channelLogoUrl')),
        )

    def get_program(self, program_id, cache=CACHE_AUTO):
        """ Get the details of the specified program.
        :type program_id: str
        :type cache: int
        :rtype Program
        """
        if cache in [CACHE_AUTO, CACHE_ONLY]:
            # Try to fetch from cache
            program = kodiutils.get_cache(['program', program_id])
            if program is None and cache == CACHE_ONLY:
                return None
        else:
            program = None

        if not program:
            # Fetch from API /20251014
            response = util.http_get(API_ENDPOINT + '/%s/detail3/%s' % (self._mode(), program_id),
                                     token=self._tokens.access_token if self._tokens else None,
                                     profile=self._tokens.profile if self._tokens else None)
            program = json.loads(response.text)
            kodiutils.set_cache(['program', program_id], program)

        channel = 'VTM' # /20251014
        seasons = {}
#        for item_season in program.get('seasonIndices', []): /20251014
        for item_season in program.get('seasonPicker', {}).get('indices', []):
            episodes = []

            # Fetch season /20251014
            season_response = util.http_get(API_ENDPOINT + '/%s/detail3/%s?selectedSeasonIndex=%s' % (self._mode(), program_id, item_season),
                                            token=self._tokens.access_token if self._tokens else None,
                                            profile=self._tokens.profile if self._tokens else None)
            # season = json.loads(season_response.text).get('selectedSeason') /20251014
            season = json.loads(season_response.text).get('seasonPicker', {}).get('selected')
            for item_episode in season.get('episodes', []):
                badge = item_episode.get('badge')
                warning = badge.get('label') + '\n' if badge else ' '
                warning = f'[B][COLOR=yellow]{warning}[/COLOR][/B]'
                description = warning + item_episode.get('description') if item_episode.get('description') else warning
                episodes.append(Episode(
                    episode_id=item_episode.get('id'),
                    program_id=program_id,
                    program_name=program.get('name'),
                    number=item_episode.get('index'),
                    season=item_season,
                    name=item_episode.get('title'),
                    description=description,
                    duration=item_episode.get('durationSeconds'),
                    thumb=item_episode.get('imageUrl'),
                    fanart=item_episode.get('imageUrl'),
                    # geoblocked=program.get('blockedFor') == 'GEO',
                    # remaining=item_episode.get('remainingDaysAvailable'),
                    channel=channel,
                    # legal=program.get('legalIcons'),
                    # aired=item_episode.get('broadcastTimestamp'),
                    # progress=item_episode.get('playerPositionSeconds', 0),
                    # watched=item_episode.get('doneWatching', False),
                ))

            seasons[item_season] = Season(
                number=item_season,
                episodes=episodes,
                channel=channel,
                # legal=program.get('legalIcons'),
            )

        return Program(
            program_id=program.get('id'),
            name=program.get('name'),
            description=program.get('description'),
            thumb=program.get('landscapeTeaserImageUrl'),
            fanart=program.get('backgroundImageUrl'),
            # geoblocked=program.get('blockedFor') == 'GEO',
            seasons=seasons,
            channel=channel,
            year = (program.get('headerLabels') or [{}])[0].get('label'),
            legal=program.get('legalText'),
            # my_list=program.get('addedToMyList'),  # Don't use addedToMyList, since we might have cached this info
        )

    @staticmethod
    def get_episode_from_program(program, episode_id):
        """ Extract the specified episode from the program data.
        :type program: Program
        :type episode_id: str
        :rtype Episode
        """
        for season in list(program.seasons.values()):
            for episode in season.episodes:
                if episode.episode_id == episode_id:
                    return episode

        return None

    @staticmethod
    def get_next_episode_from_program(program, season, number):
        """ Search for the next episode in the program data.
        :type program: Program
        :type season: int
        :type number: int
        :rtype Episode
        """
        next_season_episode = None

        # First, try to find a match in the current season
        for episode in [e for s in list(program.seasons.values()) for e in s.episodes]:
            if episode.season == season and episode.number == number + 1:
                return episode
            if episode.season == season + 1 and episode.number == 1:
                next_season_episode = episode

        # No match, use the first episode of next season
        if next_season_episode:
            return next_season_episode

        # We are playing the last episode
        return None

    def get_episode(self, episode_id):
        """ Get some details of the specified episode.
        :type episode_id: str
        :rtype Episode
        """
        response = util.http_get(API_ENDPOINT + '/%s/play/episodes/%s' % (self._mode(), episode_id),
                                 token=self._tokens.access_token if self._tokens else None,
                                 profile=self._tokens.profile if self._tokens else None)
        episode = json.loads(response.text)

        # Extract next episode info if available
        next_playable = episode.get('nextPlayable')
        if next_playable:
            next_episode = Episode(
                episode_id=next_playable['id'],
                program_name=next_playable['title'],
                name=next_playable['subtitle'],
                description=next_playable['description'],
                poster=next_playable['imageUrl'],
            )
        else:
            next_episode = None

        return Episode(
            episode_id=episode.get('id'),
            name=episode.get('title'),
            poster=episode.get('posterImageUrl'),
            progress=episode.get('playerPositionSeconds'),
            next_episode=next_episode,
        )

    def do_search(self, search):
        """ Do a search in the full catalog.
        :type search: str
        :rtype list[Union[Movie, Program]]
        """
        response = util.http_get(API_ENDPOINT + '/%s/search?query=%s' % (self._mode(),
                                                                         kodiutils.to_unicode(quote(kodiutils.from_unicode(search)))),
                                 token=self._tokens.access_token if self._tokens else None,
                                 profile=self._tokens.profile if self._tokens else None)
        results = json.loads(response.text)

        items = []
        for category in results.get('results', []):
            for item in category.get('teasers'):
                items.append(self._parse_teaser(item))
                # if item.get('target', {}).get('type') == CONTENT_TYPE_MOVIE:
                #     items.append(self._parse_movie_teaser(item))
                #
                # elif item.get('target', {}).get('type') == CONTENT_TYPE_PROGRAM:
                #     items.append(self._parse_program_teaser(item))
        return items

    @staticmethod
    def get_product():
        """ Return the product that is currently selected. """
        profile = kodiutils.get_setting('profile')
        try:
            return profile.split(':')[1]
        except (IndexError, AttributeError):
            return None

    def _parse_teaser(self, item, cache=CACHE_ONLY):
        """ Parse the teaser json and return a Teaser instance.
        :type item: dict
        :type cache: int
        :rtype Movie
        """
        # movie = self.get_movie(item.get('target', {}).get('id'), cache=cache)
        # if movie:
        #     return movie

        return Teaser(
            detail_id=item.get('detailId'),
            name=item.get('title'),
            thumb=item.get('imageUrl')
        )

    def _parse_detail_teaser(self, item, cache=CACHE_ONLY):
        """ Parse the teaser json and return a Teaser instance.
        :type item: dict
        :type cache: int
        :rtype Movie
        """
        # movie = self.get_movie(item.get('target', {}).get('id'), cache=cache)
        # if movie:
        #     return movie

        return Teaser(
            detail_id=item.get('target', {}).get('id'),
            name=item.get('title'),
            thumb=item.get('imageUrl')
        )

    # def _parse_movie_teaser(self, item, cache=CACHE_ONLY):
    #     """ Parse the movie json and return an Movie instance.
    #     :type item: dict
    #     :type cache: int
    #     :rtype Movie
    #     """
    #     movie = self.get_movie(item.get('target', {}).get('id'), cache=cache)
    #     if movie:
    #         return movie
    #
    #     return Movie(
    #         movie_id=item.get('target', {}).get('id'),
    #         name=item.get('title'),
    #         thumb=item.get('imageUrl'),
    #         geoblocked=item.get('blockedFor') == 'GEO',
    #     )

    # def _parse_program_teaser(self, item, cache=CACHE_ONLY):
    #     """ Parse the program json and return an Program instance.
    #     :type item: dict
    #     :type cache: int
    #     :rtype Program
    #     """
    #     program = self.get_program(item.get('target', {}).get('id'), cache=cache)
    #     if program:
    #         return program
    #
    #     return Program(
    #         program_id=item.get('target', {}).get('id'),
    #         name=item.get('title'),
    #         thumb=item.get('largeImageUrl'),
    #         geoblocked=item.get('blockedFor') == 'GEO',
    #     )

    def _parse_episode_teaser(self, item, cache=CACHE_ONLY):
        """ Parse the episode json and return an Episode instance.
        :type item: dict
        :type cache: int
        :rtype Episode
        """
        program = self.get_program(item.get('target', {}).get('programId'), cache=cache)
        episode = self.get_episode_from_program(program, item.get('target', {}).get('id')) if program else None

        return Episode(
            episode_id=item.get('target', {}).get('id'),
            program_id=item.get('target', {}).get('programId'),
            program_name=item.get('title'),
            name=item.get('label'),
            description=episode.description if episode else None,
            geoblocked=item.get('blockedFor') == 'GEO',
            thumb=item.get('imageUrl'),
            progress=item.get('playerPositionSeconds'),
            watched=False,
            remaining=item.get('remainingDaysAvailable'),
        )

    @staticmethod
    def _parse_channel(url):
        """ Parse the channel logo url, and return an icon that matches resource.images.studios.white
        :type url: str
        :rtype str
        """
        if not url:
            return None

        import os.path

        # The channels id's we use in resources.lib.modules.CHANNELS neatly matches this part in the url.
        return str(os.path.basename(url).split('-')[0])
